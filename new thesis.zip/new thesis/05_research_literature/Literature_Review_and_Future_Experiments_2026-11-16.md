# Web Search Queries and Market Movements
## Literature Review, Russian-Market Evidence and Proposed Future Experiments

**Research setting:** Russian MOEX-listed equities  
**Primary search source:** Yandex Wordstat  
**Version date:** 16 November 2026  
**Purpose:** Detailed literature synthesis and a disciplined programme of future empirical extensions  
**Status:** Research review and proposals. All experiments in Section 8 are proposed unless explicitly marked as already completed in the V6 project.

---

## Executive synthesis

The literature does not support a universal rule that more internet searches always mean higher subsequent stock volatility. Search activity can reflect several things at once: information demand, attention, uncertainty, curiosity, news exposure, or an attempt to understand a price movement that has already occurred. Search activity can therefore precede trading and volatility, follow market movements, or move with both because of a common information shock.

The Russian evidence is especially important and is not uniformly positive. Bazhenov and Fantazzini (2019) found that Google Trends did not add significant information to realized-volatility models for four liquid Russian shares once option-implied volatility and conventional volatility dynamics were considered; in several cases, search-augmented forecasts were worse. Fantazzini and Shangina (2019) reached a similarly cautious conclusion for the Russian RTS index futures market. Conversely, Teplova and Gurov's Russian MOEX study connected Google searches for issuer names plus a stock-related word to trading activity and found that synchronization between search activity and trading activity increased after the retail-investor inflow around February 2020. More recent Russian papers use Yandex topic searches, financial-stress query baskets and online-investor-platform discussions to study market regimes, market returns and investor behaviour.

The most directly relevant distinction for this thesis is between **company-specific information demand** and **market-wide uncertainty**. A search for a listed company's name plus «акции» may reflect interest in that issuer, but it may also be prompted by a dividend announcement, sanctions, earnings, an operational problem or a sharp price move. Market-wide searches for the exchange rate, key rate, sanctions or negotiations capture a different construct. The V6 firm and week fixed effects absorb common weekly shocks, so the current primary model deliberately estimates the within-firm component of attention rather than the effect of a common market-wide search shock.

The current V6 evidence is consistent with a cautious interpretation. The clean one-week pooled Park5 coefficient is positive but statistically inconclusive. A separate two-week lag, some alternative intraday estimators, the 2022 slope interaction and a small number of firm-specific slopes show secondary evidence. Returns, the overnight-inclusive volatility proxy, sector-peer effects and sanctions interactions do not show robust pooled relationships. The existing Granger-style tests show predictive content at selected horizons in both directions, not one-way causal influence.

The best next step is not a large new set of regressions. It is a short sequence of theory-led tests: validate the search measure against independent indicators, estimate one joint distributed-lag model, complete the unresolved query measurement audit, and then run a carefully specified nonlinear sensitivity. A market-wide uncertainty index and a true out-of-sample forecast test are valuable but larger extensions. All proposed tests below must preserve the current 73-firm one-week Park5 result as the benchmark.

## 1. Scope and approach of this review

This review is organized around the empirical question in the V6 thesis: whether abnormal firm-specific Russian-language search activity predicts subsequent within-session volatility in MOEX-listed shares. It gives special weight to research that has at least one of the following features:

- Russian equities, Russian investors or the MOEX trading environment;
- Yandex Wordstat or Google search-query data;
- firm-specific rather than only aggregate market-level searches;
- realized or intraday volatility, trading activity or stock returns;
- emerging-market settings with comparable information, liquidity or investor-participation conditions.

The review distinguishes full-text evidence, publisher abstracts and official publication records. Claims from an abstract are not treated as if the complete empirical tables had been audited. The earlier literature-relay package in the project archive (20 October 2026) is a useful inventory, but it contains a mix of full-text, abstract-only, programme-only and unopened materials. Its V5-era simulated power exercises and old model recommendations are not results from the current V6 panel and are not reproduced as evidence here.

This document is a literature synthesis, not a claim that an exhaustive systematic review has been completed. The source list is focused on the works most relevant to the thesis and the next research decisions.

## 2. What does an internet search measure?

### 2.1 Attention and information demand

Investor attention matters because market participants cannot process every piece of information about every security. Barber and Odean (2008) show how attention-grabbing stocks can enter individual investors' consideration sets and affect buying behaviour. Da, Engelberg and Gao (2011) develop a firm-specific abnormal search-volume measure using Google search data. Their central idea is that searching is an observable action indicating demand for information, rather than merely the supply of information through news publication.

Search data are therefore attractive because they measure an aspect of information demand. A news article may be published without being read by a potential investor, while a search requires a user to take an active step. However, this does not establish that the user is an investor or that the search is motivated by a trading decision. The distinction is important for the wording of this thesis: Wordstat is a proxy for public information demand concerning an issuer, not a direct count of investors.

The V6 ASVI measure is adapted from the abnormal-search framework of Da et al. (2011). For a firm-week, it compares the current week's raw query count with the median raw count of the preceding eight weeks. The transformation is useful because it identifies a query-volume increase relative to that query's recent baseline. It does not remove ambiguity from the search phrase, nor does it make raw attention levels directly comparable across firms.

### 2.2 Attention-driven trading and price pressure

One mechanism is that attention makes a stock more likely to enter investors' consideration sets. Additional information demand can be followed by trading, order-flow imbalance, temporary price pressure and changes in volatility. Da et al. (2011) document short-horizon price-pressure effects and subsequent reversal patterns in their market setting. The Turkish evidence of Düz Tan and Taş (2019) also finds that firm-specific abnormal search volume is associated with short-run returns, with stronger effects among smaller stocks and later price reversal.

This mechanism does not imply that every attention shock must increase volatility. Price pressure may cause a larger price move, but trading can also become more liquid and informed participation can improve price discovery. The sign depends on who searches, what information they receive, what they do with it, and the state of the market.

### 2.3 Attention, uncertainty and information arrival

A second mechanism is uncertainty. A person may search for a company because its future cash flows, dividend, sanction status, financing or operations have become less certain. The search is an information-seeking response to uncertainty, rather than a direct indicator of a desire to buy or sell.

Andrei and Hasler (2015) provide a theoretical framework in which investor attention to news and learning uncertainty jointly affect asset prices. Their model predicts that return variance and risk premia increase with attention and uncertainty, with a nonlinear relationship. Their empirical tests support an increasing relationship, while the evidence for a quadratic specification is mixed. The appropriate implication is to test whether a linear model is too restrictive, not to assume in advance that the data must exhibit a U-shape.

Szczygielski, Charteris, Bwanya and Brzeszczyński (2024) directly question whether broad stock-market search measures capture attention or uncertainty. Their stock-market-oriented Google search index, constructed with machine-learning identification of relevant search terms, predominantly reflects an uncertainty narrative. Their index is related to returns and volatility across markets. This is a strong warning against interpreting an increase in searches as pure investor attention.

### 2.4 Reverse feedback

A third mechanism runs from market movements to search activity. A large price move, unusual volatility, dividend cut or trading suspension can attract public interest. In that case, searches are partly an outcome of market events. A lagged regression can establish that the search week precedes the subsequent outcome week, but it cannot remove persistent news, anticipation or a shared information shock.

Dimpfl and Jank (2016) report strong co-movement between Dow Jones realized volatility and index-related search activity, and find that searches Granger-predict volatility in their US daily data. Their evidence shows that search data can have incremental predictive content in one setting, but it does not prove that the same relationship holds for Russian issuer-level weekly searches. The reverse direction should also be tested rather than assumed away.

### 2.5 Why a single linear sign is not guaranteed

The mechanisms above can act simultaneously. An information shock can increase searches, trading and intraday price dispersion. At the same time, the arrival of more information may reduce uncertainty, while deeper trading can reduce price impact. A pooled linear coefficient averages across these channels and across different firms and market regimes. It can be small even when some mechanisms are active.

The correct theoretical conclusion is not that a null coefficient is necessarily a failure. A null average can be consistent with heterogeneous or offsetting channels. The empirical challenge is to distinguish these explanations without changing the primary hypothesis after viewing the results.

## 3. Measuring search-based attention: strengths and limitations

### 3.1 Search indices are not interchangeable

Google Trends, Yandex Wordstat and Baidu Search Index differ in their query processing, sampling, normalization, geographical coverage and user populations. Evidence validating a Google query for US-listed firms does not automatically validate a Yandex query for Russian firms.

The original ASVI literature establishes a useful framework for abnormal search intensity, but each application must validate its own search phrases. Search strings matter. A ticker can be a common word, a product name or an acronym unrelated to a stock. A company name can also be associated with goods, services, recruitment, locations or customer complaints.

### 3.2 Evidence on measurement error

de Haan, Lawrence and Litjens (2025) examine Google ticker searches using a dataset of 2.7 billion website visits following S&P 500 ticker searches. They report that 69% of ticker searches in their setting are unrelated to investing, and that this measurement error is correlated with firm characteristics. A modified measure combining a ticker and a stock-related word better captures investor-related searches and reduces the measurement problem.

This study is highly relevant to query design, but its numeric estimate must not be transferred to Russian Wordstat. It is based on US Google ticker searches, not Russian company-name phrases. It nevertheless supports the decision to use company/brand name plus «акции» rather than a bare ticker as the primary channel. The V6 query still needs its own validation.

### 3.3 Wordstat phrase matching and query variants

Yandex states that Wordstat reports statistics for searches containing the supplied phrase, including possible grammatical forms. The weekly Dynamics interface uses Monday–Sunday weeks and provides counts and share of total Yandex queries, with region and device filters and CSV export. The documented interface history begins in January 2018, while the weekly range selector allows at most five years per request.

A Wordstat series is therefore not necessarily an exact literal-string count. Different submitted phrases may overlap in their underlying search-query sets, and correlations between their weekly counts do not reveal the intersection of individual users or search events. A composite formed by summing query counts can double-count demand. A normalized mean of query-specific ASVI values may be a candidate attention index, but it must remain a separate measurement specification until its construct and coverage are assessed.

### 3.4 A practical hierarchy of measurement evidence

For the V6 project, measurement validation should be understood in layers:

1. **Identity validity:** does the phrase refer to the intended issuer rather than another company, product or common word?
2. **Financial-intent validity:** does adding «акции» make the query reasonably stock-related, and are there important alternative meanings?
3. **Coverage validity:** is the series continuous enough to support the eight-week baseline and the planned model window?
4. **Convergent or nomological evidence:** does ASVI move in expected ways with trading volume, turnover, volatility, news or market events?
5. **Predictive validity:** does the measure add to a benchmark model in a strictly out-of-sample exercise?

Passing one layer does not guarantee the next. A dense series can still measure the wrong construct; a query can correlate with turnover because both respond to news; and a strong in-sample coefficient does not prove forecast value.

## 4. Evidence from Russia

### 4.1 Bazhenov and Fantazzini (2019): the direct Russian volatility counterexample

Bazhenov and Fantazzini examine realized-volatility and Value-at-Risk forecasts for four liquid Russian shares: Sberbank (SBER), Rosneft (ROSN), Yandex (YNDX) and Gazprom (GAZP). Their intraday dataset covers January 2016 to April 2018. They compare HAR, ARFIMA and GARCH specifications with online search data and option-implied volatility.

Their in-sample findings show that implied volatility is significant in most specifications, whereas Google Trends generally is not. In the out-of-sample analysis, models with implied volatility improve some forecasts, while search-augmented models worsen performance in several cases. Simple HAR and ARFIMA models without extra regressors often perform best. The authors suggest that search information may overlap with information already reflected in option-implied volatility.

**Implication for V6:** This is a direct Russian volatility precedent and must be discussed honestly. It weakens any broad claim that searches necessarily improve Russian stock-volatility forecasts. It does not make the current V6 design redundant: the provider, search phrase, frequency, company universe, price-variance outcome and research estimand differ. But these differences must be stated, not assumed to guarantee a positive result.

### 4.2 Fantazzini and Shangina (2019): Russian RTS futures

Fantazzini and Shangina study risk forecasting for the Russian RTS index futures market using daily data over 2006–2019. They examine whether Google Trends and implied volatility improve a broad group of volatility and risk models. Their published summary reports that predictive performance did not consistently improve when the additional variables were included and in some cases became worse, particularly when the variables were combined and during periods of high volatility when estimates became unstable.

**Implication for V6:** This is an aggregate futures-market study, not a company-level equity panel. It reinforces the need to distinguish in-sample association from true out-of-sample forecast gains.

### 4.3 Teplova and Gurov (2025; online first 2022): searches and MOEX trading activity

Teplova and Gurov study the Russian stock market using high-frequency trading data and Google search activity for Russian issuers. Their paper uses tick-by-tick trades and quotes for liquid MOEX shares, and weekly Google Trends queries with an issuer name plus a Russian stock-related word. The search sample covers August 2018 to June 2021. The original trading panel contains 32 MOEX Russia Index shares, while the usable search series covers fewer firms after ambiguous queries are excluded.

Their main contribution is broader than a direct regression of searches on next-week volatility. They examine market-microstructure invariance and the synchronization of information flow with trading activity. They report that search activity became more synchronized with trading activity from around February 2020, coinciding with a sharp increase in retail investor participation on MOEX. They do not find a comparable significant change in the synchronization of news-article arrival and trading activity.

The paper is particularly relevant because the search wording and exchange setting are close to the V6 study. It also demonstrates that Russian-language company-name searches can have ambiguous meanings: the authors exclude some issuer queries because the same wording can refer to other things, such as promotional offers.

**Implication for V6:** This work prevents a broad “first study of Russian stock searches” claim. The more specific contribution is the use of Yandex Wordstat, a 73-firm weekly panel, a clean subsequent-week Park5 outcome, and the explicit post-2022 / horizon analysis. Teplova and Gurov also motivate checking whether the relation shifted around 2020, but that should be a pre-specified secondary test rather than a search over many possible break dates.

### 4.4 Stolbov and Shchepeleva (2025): search-based Russian financial stress

Stolbov and Shchepeleva build a sentiment-based financial-stress index for Russia from January 2018 to June 2024. They use Russian-language Google and Yandex searches for terms with negative financial-stability connotations. Their index rises around the COVID-19 pandemic and the Russian-Ukrainian conflict. Their abstract reports that the search-based index precedes an alternative financial-stress measure constructed from conventional financial data and industrial production, and it captures information not fully reflected in other uncertainty indicators.

**Implication for V6:** Yandex search activity in Russia can contain information about macro-financial stress, not only attention to individual companies. This is a reason to distinguish company-specific searches from common macroeconomic/geopolitical searches. It is not direct evidence that an issuer-name query predicts issuer-specific volatility.

### 4.5 Fayzulin (2025): search attention and opinion divergence among Russian retail investors

Fayzulin studies retail-investor behaviour using more than 4.3 million messages from Tinkoff Pulse, SmartLab and MFD. The paper combines text classification and econometric analysis with search statistics for economic-political and investment topics. The HSE record and Moscow State University issue abstract report that opinion divergence has an unstable relation with stock returns on discussion days, while attention to economic-political topics (rather than the investment-topic category) is associated with future price behaviour. Patterns vary by stock-risk level and are described as unstable.

**Implication for V6:** This is important Russian evidence that search-topic categories may matter differently and that a search measure can reflect macroeconomic or political information demand rather than interest in a specific stock. It also makes a market-wide topic-search extension more credible. However, this study's topic search measures and social-platform text are not the same as issuer-specific Wordstat search counts.

### 4.6 Rodionov and Tursunov (2026): Yandex topics and the 2022 Russian market regime

Rodionov and Tursunov study weekly Yandex searches for 16 economic and 12 political topics from 2018 to 2025, using February 2022 as the main structural-change boundary. They report increased interest in topics including the yuan exchange rate, key rate and sanctions. Currency-topic searches are inversely correlated with IMOEX returns. Their Granger-style analysis reports that searches about negotiations precede market-return changes at a two-to-three-week horizon, while market returns precede later searches about exchange rates. They also identify three clusters of different market/search regimes.

**Implication for V6:** This is close in provider, frequency and historical period, but it is an aggregate topic-search study, not a firm-name attention study. It reinforces the relevance of the Russian 2022 regime and the possibility of reverse timing. Its findings should be described as another observational study of Yandex search and the IMOEX environment, not as proof that Yandex searches identify investors or cause market movements.

### 4.7 Djalilov and Ülkü (2021): actual individual-investor behaviour on MOEX

Djalilov and Ülkü use Moscow Exchange data to study aggregate Russian individual-investor equity trading during the COVID-19 shock. They report that individuals bought during the March–April 2020 market decline and remained net buyers through the recovery. They argue that the behaviour reflected a combination of regular contrarian traits and a positive demand shock, rather than a simple noise-trader story.

**Implication for V6:** This paper gives context for the changing retail-investor environment on MOEX. It does not use search data, and it cannot validate the identity of users behind Wordstat queries. It is appropriate background for explaining why the Russian market's information and participation environment changed after 2020.

### 4.8 What the Russian evidence collectively implies

The Russian studies point in different directions because they ask different questions:

| Study | Search measure | Unit / outcome | Main relevance |
|---|---|---|---|
| Bazhenov & Fantazzini (2019) | Google Trends plus option-implied volatility | Four liquid Russian stocks; realized-volatility/VaR forecasts | Search data add little once implied volatility and conventional models are considered |
| Fantazzini & Shangina (2019) | Google Trends and implied volatility | RTS futures; risk forecasts | Forecast gains are not robust; complex models can become unstable |
| Teplova & Gurov (2025; online 2022) | Google company-name + Russian stock term | MOEX stocks; high-frequency trading activity | Search/trading synchronization increased around retail-investor inflow in 2020 |
| Stolbov & Shchepeleva (2025) | Google + Yandex financial-stress topics | National Russian stress index | Search data contain macro-financial uncertainty information |
| Fayzulin (2025) | Economic-political and investment-topic search statistics plus social-platform posts | Russian issuer returns and retail-investor opinion divergence | Topic type and stock-risk conditions matter; patterns are not uniformly stable |
| Rodionov & Tursunov (2026) | Weekly Yandex macro/political topics | IMOEX returns and market regimes | Search/market timing is bidirectional at selected horizons around 2022 |
| Djalilov & Ülkü (2021) | No search data; MOEX retail-trading records | Aggregate retail investor trades | Russian retail participation and behaviour changed during COVID-19 |

The defensible conclusion is that online search and Russian-market activity have been studied from several angles. The V6 thesis has a narrower gap: a cleaned, issuer-level Wordstat panel linked to subsequent within-session volatility, with explicit treatment of weekly timing, issuer query wording and the post-2022 market regime.

## 5. Evidence from emerging and developed markets

### 5.1 Index-level volatility: Dimpfl and Jank

Dimpfl and Jank (2016) use searches for the Dow Jones index and daily realized volatility. They report strong co-movement, Granger-predictive content from search activity to volatility, and improvements in volatility forecasts in their setting. This is a positive precedent, but it is an index-level daily US study. The V6 research unit is the firm-week in a Russian market, so the findings cannot be transferred mechanically.

### 5.2 Emerging markets: Turkey

Düz Tan and Taş (2019) construct abnormal Google search volume for stocks listed on Borsa Istanbul. Their results indicate that the measure captures firm-specific attention and that high attention is followed by higher short-term returns, particularly among smaller companies. They also report a reversal over a longer horizon and a portfolio-sorting premium in their sample.

The Turkish study is relevant for three reasons: it is an emerging market, it uses firm-level search intensity, and it demonstrates that short-run and long-run effects can differ. It is evidence about returns and price pressure, not a direct replication of the V6 volatility model.

### 5.3 Emerging markets: Vietnam

Bui and Nguyen (2019) study Google search activity and stock-market activity in Vietnam. They report a strong correlation between search volume and trading volume. Market-wide attention increases illiquidity and volatility, while company-level attention has mixed signs for those outcomes. This is a particularly useful comparison because it separates broad market attention from company-specific searches.

Its implication for V6 is important: a company-specific search measure can produce mixed firm-level relationships even when aggregate market attention is positively related to volatility. It also supports treating turnover as a relevant validation variable while remembering that turnover may be part of the causal channel rather than an ordinary confounder.

### 5.4 Emerging markets: India

Swamy, Dharani and Takeda (2019) study Google Search Volume Index for BSE 500 companies in India over 2012–2017. Using quantile regression, they report that higher search attention predicts positive returns over the next one or two weeks, with stronger results at higher attention quantiles. This supports examining distributional heterogeneity, although the outcome is returns rather than within-session volatility.

### 5.5 Emerging-market attention categories

Peltomäki, Graham and Hasselgren (2018) construct attention proxies for market categories in emerging economies and report explanatory relationships with stock-market volatility. Their work supports the idea that broad market-category attention can matter, but it does not replace firm-specific search measurement.

### 5.6 Systematic review evidence

Ayala, Gonzálvez-Gallego and Arteaga-Sánchez (2024) review 56 studies published between 2010 and 2021 using Google Search Volume Index in stock-market research. Their review reports broad positive relationships with volatility and trading volume and discusses forecasting value. The review also documents variation in keyword choice, market region and data frequency.

This broad synthesis should be read alongside the Russian counterexamples. A positive average relationship across a large literature does not imply that every market, provider, query or model will show the same result. Provider differences, measurement error, query intent, market microstructure and the forecast benchmark matter.

## 6. Synthesis: what the literature predicts for the V6 design

### 6.1 The sign is not predetermined

Attention-driven trading may raise trading intensity and price dispersion, but information arrival may reduce uncertainty, and liquidity can change price impact. A positive coefficient is plausible, but not guaranteed. A statistically inconclusive average coefficient is also plausible when the sample combines firms and regimes with different responses.

### 6.2 Horizon matters

Da et al. (2011), the Turkish study and the Indian study all motivate short-horizon effects and possible subsequent reversal or decay. Dimpfl and Jank find a short-horizon relationship in an index setting. Rodionov and Tursunov report selected two-to-three-week topic-search relationships for IMOEX returns. The V6 separate t−2 result is therefore a reasonable secondary finding. However, two separate models do not prove that the t−2 slope is significantly different from the t−1 slope. That requires a joint model with both lags and a direct contrast.

### 6.3 Russian market regime matters

The Russian equity market experienced a large increase in individual-investor participation around 2020, and substantial geopolitical, sanctions, trading and information changes in 2022. The Teplova–Gurov and Rodionov–Tursunov studies provide relevant evidence that the search/trading or search/market relationship may shift in such periods. A 2022 interaction is therefore well motivated, but it remains a broad regime-slope comparison rather than a causal estimate of any one event.

### 6.4 Firm-level and market-wide attention are distinct

Company-specific searches vary across firms, while macroeconomic and political search topics often move together across the market. In the V6 model, week fixed effects absorb a common search shock that is identical for all firms in a given week. To study market-wide search attention, a separate IMOEX-level model is more appropriate. Alternatively, a market-wide index can be interacted with pre-existing firm exposures, with a clear theoretical rationale.

### 6.5 Measurement validity is central

The de Haan et al. (2025) measurement-error study and the Russian query-ambiguity issues in Teplova and Gurov show why query construction matters. A company-name + «акции» phrase improves financial relevance, but it still measures public search-query activity, not unique investor attention. The corrected SFIN legacy-name query and carefully selected company aliases should be treated as a separate measurement experiment.

## 7. Research gap and contribution statement

A broad novelty claim such as “the first study of investor attention in the Russian stock market” is not defensible. Russian studies already examine Google company-name searches and MOEX trading activity, Google Trends in Russian volatility forecasts, Yandex topic searches and market returns, Yandex/Google financial stress, and retail-investor search attention alongside social-platform discussion.

The defensible contribution is narrower:

> This thesis examines whether issuer-specific Russian-language search activity measured through Yandex Wordstat is associated with subsequent within-session price variance across a cleaned panel of MOEX-listed firms. It uses weekly firm-name search activity, a consistent eight-week abnormal-search transformation, daily OHLC-based intraday variance, a timing rule that addresses the 2025 MOEX weekend-session allocation, and a separate analysis of the 2022 regime-slope change. The study distinguishes company-specific information demand from market-wide uncertainty and does not interpret search counts as verified investor identities.

The design's value lies in the combination of provider, issuer-level unit, weekly panel, specific volatility measure, timing control and Russian market history. The review does not establish that no other study has ever used Yandex issuer-level Wordstat data. The contribution should be stated without a “first” claim unless a broader search of Russian-language databases and full texts supports it.

## 8. Proposed future experiments and empirical extensions

The items below are **proposals, not completed results**. They are empirical extensions rather than randomized experiments. They should be run one bounded stage at a time, with the source inputs and exact model registered before estimation. The current primary specification should remain the benchmark.

### Experiment 1 — ASVI measurement validation

**Priority:** Very high. **Purpose:** Determine whether the existing company-name Wordstat ASVI behaves like an issuer-information-demand measure.

**Question:** Do firm-specific ASVI movements coincide with or precede observable measures of firm-level attention and activity, such as turnover, trading volume, absolute returns, intraday volatility and issuer-news intensity?

**Data required:** The current frozen 73 × 419 search panel; the existing daily/weekly OHLC and ruble VALUE series; and, if a reliable source can be assembled, a weekly count of unique company-specific news items or official issuer disclosures. The news source and deduplication rules must be documented before collection.

**Proposed design:**

1. Freeze a validation sample and list the exact external news source, article identifiers, issuer mapping and deduplication method.
2. Construct weekly outcomes separately: log ruble turnover, log share volume, absolute weekly return (or absolute market-adjusted return only if benchmark construction is consistent), Park5, and the weekly number of unique issuer-related news/disclosure items.
3. Report contemporaneous correlations and within-firm panel associations, and then separately report lagged associations. Keep outcomes and timing distinct.
4. Use the existing primary fixed effects where appropriate, but describe the resulting association as convergent or nomological evidence, not proof of investor identity.
5. Do not automatically add volume/turnover to the main model. Trading activity could be a mechanism through which attention affects volatility, so treat turnover augmentation as a nested diagnostic rather than a universal control.

**Decision rule:** If ASVI has little relationship with any independent activity or information proxy, weaken the language about attention and consider whether the measure is better described as public issuer-search activity. If ASVI relates to activity but more strongly to news intensity than to turnover, interpret it primarily as information demand around issuer news. If it relates to both, present the measures as complementary evidence rather than as proof of causality.

**Risks:** The news-count measure can be incomplete, source-dependent and contaminated by syndicated duplicates. Turnover is not a perfect external validation measure because it can be on the mechanism path. Correlations alone are not construct validation.

### Experiment 2 — Joint distributed-lag model

**Priority:** Very high. **Purpose:** Determine whether the current t−2 association contains information beyond the adjacent t−1 ASVI value.

**Question:** Does ASVI from two weeks earlier predict current Park5 after controlling for ASVI from the immediately preceding week?

**Proposed model:**

$$
\ln(Park5_{i,t})=\alpha_i+\lambda_t+\beta_1 ASVI_{i,t-1}+\beta_2 ASVI_{i,t-2}+\rho\ln(Park5_{i,t-1})+\varepsilon_{i,t}.
$$

**Implementation rules:**

- Generate both lags on the complete 419-week Monday calendar before filtering observations.
- Use the same clean outcome window and a common matched estimation sample when comparing the one- and two-week coefficients.
- Keep firm and week fixed effects and the same outcome definition.
- Use the primary covariance choice consistently for this secondary joint test, with the calendar-gap treatment documented. Do not swap covariance construction between coefficients.
- Test H0: β1 = 0, H0: β2 = 0, H0: β1 = β2, and H0: β1 + β2 = 0. Report the covariance-aware confidence interval for the combined two-week cumulative effect.
- Treat this as a secondary model. The current one-week model remains the main confirmatory estimate.

**Decision rule:** If β2 remains informative after β1 is included, this supports delayed incremental information. If β2 becomes small, the two-week-only result may mainly reflect persistence in ASVI that was not separated from the one-week lag. If β1 and β2 are jointly insignificant, the apparent two-week-only relationship may not be stable when lags are entered together.

**Risks:** Multicollinearity between adjacent ASVI values can widen uncertainty. The common matched sample may be smaller than the current separate-lag samples. Statistical significance at one lag is not evidence that the effect peaks at that lag.

### Experiment 3 — Future-ASVI placebo and reverse-timing diagnostic

**Priority:** High. **Purpose:** assess whether the apparent timing relationship could reflect persistent common news or feedback from volatility to search.

**Question:** Does a future ASVI value appear to explain a past volatility outcome after the specified lags and fixed effects are included?

**Proposed design:** Add a pre-specified lead of ASVI, for example ASVI(t+1), to a clearly labelled placebo equation for current Park5, using calendar-aligned leads and a sample that avoids edge effects. Report the lead coefficient with the actual lag terms and fixed effects. Compare it with the already completed bidirectional Granger-style tests in Part 4I; do not repeat the existing Granger family merely to generate more p-values.

**Decision rule:** A nonzero future-ASVI coefficient is a warning that persistent shocks, anticipatory search or reverse feedback may be present. It does not mechanically prove reverse causality. A near-zero lead is reassuring about this specific timing placebo but does not establish exogeneity.

**Risks:** Future searches can respond to information not observed in the model, and the result depends on the lead horizon. Treat the placebo as a diagnostic, not a formal causal identification test.

### Experiment 4 — Corrected SFIN and issuer-alias measurement audit

**Priority:** High for measurement completeness; currently blocked by source collection.

**Question:** Can issuer-name variants recover historically valid search coverage where the current query is sparse or fails after a corporate name change?

**Existing SFIN collection plan:** Five separate phrases, each requiring two separate weekly CSV exports:

1. «САФМАР Финансовые инвестиции акции»
2. «акции САФМАР Финансовые инвестиции»
3. «САФМАР акции»
4. «акции САФМАР»
5. «ЭсЭфАй акции»

For each phrase, the saved plan uses W1 (27 August 2018–27 August 2023, expected 261 Monday labels) and W2 (28 August 2023–6 September 2026, expected 158 Monday labels). Combined, the two windows cover the 419-week project grid. Settings are all regions, all devices and weekly Dynamics. The ten original CSVs must remain separate and retain their original headers. Current status is **not collected; authenticated Wordstat or authorised API access is required**.

**Validation steps after collection:** confirm exact phrase header, weekly dates, all 419 labels, no duplicate or missing weeks, region/device settings, issuer identity by historical name date, zero-rate and zero-run metrics, ASVI availability and transition-date behaviour. Never splice raw counts from different query variants or sum them.

**Extension to other issuers:** Review the existing manual alias queue only where issuer history and query semantics justify it. A candidate composite must be registered before any volatility regression. Compare the original single query with each variant and any justified normalized index on coverage and measurement reliability first.

**Decision rule:** retain SFIN only if at least one historical phrase provides a credible, continuous issuer-specific measure. If no phrase has adequate coverage, keep SFIN excluded. If a new variant is valid only after a rebranding date, use it only for the corresponding post-change sensitivity. Do not change the 73-firm primary panel until a separate versioned decision is made.

**Risks:** Wordstat phrase counts may overlap; pairwise correlation is not a deduplication test; name changes may change users' search behaviour; some phrases may refer to unrelated products or companies.

### Experiment 5 — Theory-led nonlinear attention specification

**Priority:** High, after measurement validation and distributed-lag work.

**Question:** Does the conditional ASVI–Park5 relationship depart from a linear form?

**Proposed design:** Standardize or centre ASVI using a rule fixed before estimation. Estimate a model containing a linear ASVI term and its squared term, with the same firm and week effects, lagged Park5, sample and timing logic as the benchmark. Report the joint test of the linear and quadratic terms, the sign and uncertainty of the curvature, marginal effects across the observed ASVI support, and the location of any turning point only if it lies within the data support.

**Theory:** Andrei and Hasler (2015) motivate an increasing but potentially nonlinear relationship through attention and learning uncertainty. Their empirical evidence for a quadratic relationship is mixed. Therefore do not assume a U-shape, do not impose a negative linear coefficient and positive quadratic coefficient, and do not select a curve based on the smallest p-value.

**Decision rule:** A meaningful nonlinear result requires stable curvature, adequate data support across the attention distribution, and robustness to reasonable scaling and influential observations. A turning point outside the observed ASVI range is not economically informative. If the quadratic term is unstable or not supported, retain the linear result and report that the proposed nonlinearity was not detected.

**Risks:** Squared regressors can be sensitive to outliers and collinearity; the quadratic term can have poor finite-sample size; many alternative transformations create specification searching. Keep it to one theoretically motivated functional-form sensitivity.

### Experiment 6 — Separate company-specific news and market-wide uncertainty

**Priority:** Medium to high; larger data-collection task.

**Question:** Are company-name searches associated with next-week volatility because they proxy for issuer-specific attention, because they respond to issuer news, or because a common macro-financial uncertainty shock affects many firms at once?

**Two distinct strands should be kept separate:**

**A. Company-specific news:** build a deduplicated weekly issuer-news/disclosure series using a fixed source list and company mapping. Test whether issuer ASVI adds information after lagged news intensity is included, while reporting that news can be a source of attention and may be a mediator rather than a confounder.

**B. Market-wide uncertainty searches:** construct a separate Yandex topic basket covering a short, theoretically justified set of macro-financial topics (for example, exchange rates, key rate, sanctions and negotiations). Validate these phrases and avoid mixing unrelated topic families.

Because the existing firm model contains week fixed effects, an identical market-wide index for every firm-week will be absorbed. Test the common index in a separate IMOEX-level model, or interact it with pre-existing firm exposure such as sector membership or independently measured currency/commodity sensitivity. Do not insert the common index into the current two-way-FE firm model and interpret a dropped regressor as evidence of no effect.

**Decision rule:** Keep company-specific and market-wide results as separate strands. A company-news series that explains ASVI may show that ASVI tracks news demand; it does not make ASVI useless. A market-wide uncertainty series may explain IMOEX risk without establishing firm-specific attention effects.

**Risks:** News databases may have incomplete historical coverage, source bias and duplicate articles. Topic dictionaries can be overfit. Market-level and firm-level estimates have different estimands.

### Experiment 7 — Out-of-sample forecasting comparison

**Priority:** Medium; necessary only if the thesis intends to claim forecast usefulness.

**Question:** Does adding prior-week ASVI improve genuine future forecasts of Park5 relative to a benchmark using only past volatility and a fixed set of available market variables?

**Proposed design:**

1. Define an expanding-window or rolling-origin scheme on the clean timing sample. A possible design is a minimum initial training window of approximately 156 weeks, followed by sequential one-week-ahead forecasts through the available clean endpoint. The final start date and horizon must be registered before the forecast run.
2. Benchmark model: forecast log Park5 using its own lag structure and any controls selected independently of the ASVI result. Augmented model: exactly the same benchmark plus ASVI(t−1). Keep the forecast target, training window and estimation procedure identical.
3. Preserve the complete calendar. Do not treat 2022 suspension gaps as adjacent observations. Do not use post-weekend-overlap data in a strict one-week test unless a separate real-time alignment is established.
4. Evaluate forecasts with a pre-declared loss function appropriate to the target, such as squared-error loss and QLIKE for variance forecasts, where the construction is valid. Report loss differences and confidence intervals; use a suitable Diebold–Mariano-type comparison with dependence-aware inference. If many forecast models are compared, use a declared model-comparison procedure rather than ranking by raw losses.
5. Do not tune query variants, lags or model architecture on the final test period.

**Decision rule:** Only claim forecast improvement if the augmented model improves the predeclared out-of-sample loss measure with statistically and economically credible evidence. If not, report that ASVI has an in-sample association at selected horizons but no demonstrated forecast gain.

**Risks:** The clean sample is not long, the 2022 closure creates unusual gaps, and the 2025 timing rule shortens the forecast evaluation window. A lack of forecast gain does not invalidate an in-sample association.

### Experiment 8 — Pre-specified firm heterogeneity by size and liquidity

**Priority:** Lower; only after the core measurement and lag work.

**Question:** Are search–volatility associations systematically different for more or less liquid companies, or companies with different pre-existing market characteristics?

**Proposed design:** Use characteristics measured before the main analysis period or before the relevant outcome window, such as average 2018–2020 ruble turnover or a pre-specified liquidity ranking. Define groups before estimating interactions. Estimate a small number of interactions between ASVI and the pre-defined characteristic, retaining firm and week effects. Report the continuous interaction where feasible, not a large collection of arbitrary sector splits. Adjust for the declared family of interactions.

**Decision rule:** Only report heterogeneity if the interaction is supported by a coherent theory, robust inference and a reasonable range of underlying firm observations. Avoid drawing conclusions from isolated raw firm p-values.

**Risks:** Seventy-three firms is a modest cross-sectional universe; subgroup models can be underpowered; liquidity can itself respond to news and investor attention. Do not treat current turnover as an exogenous firm characteristic.

### Optional Experiment 9 — A 2020 retail-participation regime sensitivity

Teplova and Gurov report a change in search/trading synchronization around February 2020. A pre-specified 2020 interaction could be examined as a single secondary regime test, with the same clean timing and fixed-effects discipline. This should not become a breakpoint search over many dates. It should be undertaken only if the supervisor agrees that the 2020 retail-participation mechanism is a distinct research question from the 2022 geopolitical/market-regime test.

## 9. Recommended order of work

The following order minimizes unnecessary model expansion and preserves the current empirical result:

| Order | Work package | Why this order | Output / decision |
|---:|---|---|---|
| 1 | ASVI validation table | Establish what the current query measure behaves like before adding more modelling | Measurement-validation report and interpretation boundary |
| 2 | Joint t−1/t−2 distributed-lag model | Directly resolves the strongest ambiguity in the existing lag results | Conditional lag coefficients, equality test and cumulative effect |
| 3 | Future-ASVI placebo | Checks for residual timing feedback and shared shocks | Placebo diagnostic with careful interpretation |
| 4 | SFIN and selected query-variant collection | Repairs a known query-definition gap without changing the primary sample prematurely | Ten raw exports, coverage audit and retain/exclude decision |
| 5 | One nonlinear sensitivity | Tests a theory-based functional form after measurement quality has been assessed | Marginal-effect curve and curvature test |
| 6 | News / market-wide uncertainty strand | Adds the Russian information-environment context but requires new data | Separate firm-news and IMOEX-level evidence |
| 7 | Out-of-sample forecasting | Only needed to make a forecast-usefulness claim | Benchmark-versus-ASVI forecast comparison |
| 8 | Pre-specified firm heterogeneity | Optional, lower priority given modest firm count | Small, theory-led interaction family |

The current V6 primary result must remain visible in every report. A future experiment can qualify, explain or extend it, but it cannot retroactively replace it because another specification has a smaller p-value.

## 10. Suggested literature-review chapter structure

A thesis Chapter 1 can be organized as follows:

1. **Investor attention and limited information processing.** Define attention, information demand and the price-pressure mechanism. Distinguish investor attention from generic public interest.
2. **Online search data as a proxy.** Explain ASVI, query choice, normalization, provider differences, Wordstat phrase matching and measurement error.
3. **Search attention, uncertainty and volatility.** Present the competing information-arrival, uncertainty-reduction, market-liquidity and reverse-feedback mechanisms. Discuss nonlinear possibilities.
4. **International and emerging-market evidence.** Compare US index-level evidence, Turkey, India and Vietnam, emphasizing differences in outcome and data frequency.
5. **Evidence from the Russian market.** Give priority to Bazhenov–Fantazzini, Fantazzini–Shangina, Teplova–Gurov, Stolbov–Shchepeleva, Fayzulin, Rodionov–Tursunov and Djalilov–Ülkü.
6. **Research gap, questions and hypotheses.** State the narrow firm-level Wordstat/Park5 contribution and the limits of any novelty claim.

## 11. References

### Russian-market and Russia-relevant studies

- Bazhenov, T., & Fantazzini, D. (2019). Forecasting realized volatility of Russian stocks using Google Trends and implied volatility. *Economics in Industry, 12*(1), 79–88. https://doi.org/10.17073/2072-1633-2019-1-79-88
- Djalilov, A., & Ülkü, N. (2021). Individual investors’ trading behavior in Moscow Exchange and the COVID-19 crisis. *Journal of Behavioral and Experimental Finance, 31*, 100549. https://doi.org/10.1016/j.jbef.2021.100549
- Fayzulin, M. S. (2025). Search attention and opinion divergence in explaining retail investor behavior. *Vestnik Moskovskogo Universiteta. Series 6: Economics, 60*(5), 3–41. https://doi.org/10.55959/MSU0130-0105-6-60-5-1
- Fantazzini, D., & Shangina, T. (2019). The importance of being informed: Forecasting market risk measures for the Russian RTS index future using online data and implied volatility over two decades. *Applied Econometrics, 55*, 4–31. https://doi.org/10.24411/1993-7601-201910008
- Rodionov, D. S., & Tursunov, B. A. (2026). Analysis of structural changes in the behavior of Russian stock market investors using search query data. *Research and Development. Economics of the Firm, 15*(1), 124–129. https://doi.org/10.12737/2306-627X-2026-15-1-124-129
- Stolbov, M., & Shchepeleva, M. (2025). A sentiment-based financial stress index for Russia. *Borsa Istanbul Review, 25*(2), 350–359. https://doi.org/10.1016/j.bir.2025.01.007
- Teplova, T., & Gurov, S. (2025; online first 2022). Nonlinear intraday trading invariance in the Russian stock market. *Annals of Operations Research, 352*, 441–469. https://doi.org/10.1007/s10479-022-04683-7

### International theory and search-attention evidence

- Andrei, D., & Hasler, M. (2015). Investor attention and stock market volatility. *The Review of Financial Studies, 28*(1), 33–72. https://doi.org/10.1093/rfs/hhu059
- Ayala, M. J., Gonzálvez-Gallego, N., & Arteaga-Sánchez, R. (2024). Google search volume index and investor attention in stock market: A systematic review. *Financial Innovation, 10*, Article 70. https://doi.org/10.1186/s40854-023-00606-y
- Barber, B. M., & Odean, T. (2008). All that glitters: The effect of attention and news on the buying behavior of individual and institutional investors. *The Review of Financial Studies, 21*(2), 785–818. https://doi.org/10.1093/rfs/hhm079
- Bui, V. X., & Nguyen, H. T. (2019). Stock market activity and Google Trends: The case of a developing economy. *Journal of Economics and Development, 21*(2), 191–212. https://doi.org/10.1108/JED-07-2019-0017
- Da, Z., Engelberg, J., & Gao, P. (2011). In search of attention. *The Journal of Finance, 66*(5), 1461–1499. https://doi.org/10.1111/j.1540-6261.2011.01679.x
- de Haan, E., Lawrence, A., & Litjens, R. (2025). Measuring investor attention using Google search. *Management Science, 71*(7), 6275–6297. https://doi.org/10.1287/mnsc.2022.02174
- Dimpfl, T., & Jank, S. (2016). Can internet search queries help to predict stock market volatility? *European Financial Management, 22*(2), 171–192. https://doi.org/10.1111/eufm.12058
- Düz Tan, S., & Taş, O. (2019). Investor attention and stock returns: Evidence from Borsa Istanbul. *Borsa Istanbul Review, 19*(2), 106–116. https://doi.org/10.1016/j.bir.2018.10.003
- Herwartz, H., & Xu, F. (2022). Structural transmissions among investor attention, stock market volatility and trading volumes. *European Financial Management, 28*(1), 260–279. https://doi.org/10.1111/eufm.12315
- Peltomäki, J., Graham, M., & Hasselgren, A. (2018). Investor attention to market categories and market volatility: The case of emerging markets. *Research in International Business and Finance, 44*, 532–546. https://doi.org/10.1016/j.ribaf.2017.07.124
- Swamy, V., Dharani, M., & Takeda, F. (2019). Investor attention and Google Search Volume Index: Evidence from an emerging market using quantile regression analysis. *Research in International Business and Finance, 50*, 1–17. https://doi.org/10.1016/j.ribaf.2019.04.010
- Szczygielski, J. J., Charteris, A., Bwanya, P. R., & Brzeszczyński, J. (2024). Google search trends and stock markets: Sentiment, attention or uncertainty? *International Review of Financial Analysis, 91*, Article 102549. https://doi.org/10.1016/j.irfa.2023.102549

### Official data documentation

- Yandex. Wordstat interface and Dynamics. https://yandex.ru/support2/wordstat/en/interface/new
- Yandex. Structure of the Wordstat API: weekly, monthly and daily query dynamics. https://yandex.ru/support2/wordstat/en/content/api-structure
- Bank of Russia (28 February 2025). Setting parameters of weekend trading. https://www.cbr.ru/press/event/?id=23428
- Moscow Exchange (24 February 2025). Moscow Exchange launches weekend trading on the stock market. https://www.moex.com/n77931

---

**End of literature review and future-experiment programme.**