# Web Search Queries and Market Movements
## V6 Methodology — Draft 1

**Draft date:** 14 November 2026  
**Research setting:** Russian MOEX-listed equities  
**Search source:** Yandex Wordstat  
**Main outcome:** Weekly five-session-equivalent Parkinson intraday variance  
**Status:** Methodology draft based on completed Parts 1–4B and Part 4C. The single-query baseline and current model definitions are frozen. A proposed Russian multi-keyword extension is specified below but has not yet been collected or estimated. The 2022 slope-change analysis has been estimated as a secondary test.

---

## 1. Research objective and scope

This study examines whether abnormal online search interest in an individual Russian listed company is associated with subsequent within-session stock-price variance. It uses weekly Yandex Wordstat search counts and daily MOEX trading data for a panel of 75 firms over the available period beginning in August 2018.

The main question is:

> Does a rise in firm-specific Russian-language search interest during a completed week predict higher or lower intraday price variance for that firm during the following MOEX trading week?

The study also examines whether this predictive association changed after the geopolitical and market disruption that began in February 2022.

The thesis is an observational panel study. It does not identify a causal effect of investor attention. Search activity is a proxy for public interest in a company. The data do not identify the person who made a search, whether that person is an investor, whether a search led to a trade, or whether the person is a retail or institutional participant.

The word *predict* refers to the time ordering of the variables in the specified in-sample panel model. It does not mean that the study demonstrates improved out-of-sample forecasts. A separate rolling forecast exercise would be required for that claim.

The primary estimand is deliberately narrow: the within-firm association between prior-week abnormal search activity and the following week's trading-session high-low variance, after controlling for the firm's own lagged variance and common weekly shocks.

## 2. Market sample and data sources

### 2.1 Firm universe and period

The audited working universe contains 75 MOEX-listed securities and 419 Monday-labelled weeks, from 27 August 2018 through 31 August 2026. The sample universe was frozen and documented in Part 1. It is not the same as earlier pilot samples that used 15 or 40 firms.

The original daily OHLC, market and other non-search source data remain unmodified. On 15 November 2026, the Wordstat search exports were reorganized: one selected Russian-language primary query per included firm remains in the active company folder, redundant and excluded query exports were moved to a hash-verified V6 archive, and one YKEN query was separated as out-of-sample. V6 analytical outputs are saved in the separate research workspace, with input manifests, audit scripts and reproducibility records.

The analysis uses:
- weekly Yandex Wordstat counts and query-share percentages;
- daily MOEX open, high, low, close, volume and value data;
- daily and weekly IMOEX market-session data for the volatility-availability rule;
- official MOEX security metadata and trading-history checks;
- a v5.3 dividend workbook for secondary dividend-adjusted range and return diagnostics.

### 2.2 Security identity

The 75 sample tickers map to 75 unique ISINs in the MOEX security-master audit. The YNDX file contains a security identity transition: old YNDX is followed by new YDEX in 2024. No return is calculated across that identity transition. The Latin ticker-only search series is also treated as a query-definition break around the change. A ticker series must not be spliced across YNDX and YDEX without a documented bridge and a new eight-week ASVI warm-up.

The main name-based attention query is not a traded-security return series and does not bridge the security identity for return calculation. The return strand remains secondary.

### 2.3 Daily price-data checks

The Part 3 audit covered 150,449 active daily OHLC observations. The 75 combined weekly company files reconciled against fresh daily aggregation for weekly OHLC, session counts, volume and value. Linked IMOEX fields also reconciled.

The daily OHLC source is used to construct the intraday variance estimators directly. It is not used to calculate a return across a long suspension gap or across the YNDX/YDEX identity break.

## 3. Measuring firm-specific search attention

### 3.1 Current primary query

The frozen primary attention series is the Russian-language company or brand name plus the word «акции». The Latin ticker-only query is retained as a separate validation channel. The two channels are not added, averaged or switched firm by firm.

The Part 4B review reconstructed all 150 query definitions from the Wordstat export headers. All 75 current primary phrases contain Cyrillic and «акции». Across firms, the median raw weekly count is 723 for the Russian-language name/brand channel and 98 for the Latin ticker-only channel.

This supports the Russian-language channel as the current primary measure. It does not establish that every query is made by an investor or that the query captures every way in which Russian users search for a company.

### 3.2 Current query coverage exceptions

Search coverage is not equally strong for all firms. Canonical ASVI is undefined when the current count is zero or the preceding eight-week median is zero. The current Russian-language channel has seven additional firms with fewer than 300 valid ASVI observations and one firm with no valid canonical ASVI.

SFIN is a specific query-definition problem. The saved Wordstat export uses «СФИ акции», which has 389 zero-count weeks out of 419 and no valid canonical ASVI observations. The current MOEX short name is «ЭсЭфАй ао». A Wordstat export for the corrected issuer-name query has not yet been collected. SFIN is therefore excluded from the current Russian-name primary estimation sample. The Latin SFIN series must not be silently substituted for its missing Russian-name series.

The current SBER Wordstat export is «Сбер акции». It is not «Сбербанк акции». Yandex states that Wordstat phrase statistics include all possible forms of the words in the phrase. Therefore, a later query using «Сбербанк» may already include grammatical forms such as «Сбербанка», but that statement does not establish that the existing «Сбер акции» export contains searches using the different brand form «Сбербанк». The exact query definition must always be taken from the saved export header, not from memory.

Low-coverage firm-weeks remain missing in canonical ASVI. They are not set to zero or interpolated. The firm is not removed solely because its search volume is small. The estimation sample is allowed to vary with valid query coverage, and the missingness is reported.

### 3.3 Canonical abnormal search volume

For firm i and search week t, canonical abnormal search volume is:

\[
ASVI_{i,t}
=
\ln(SVI_{i,t})
-
\ln\left[
\operatorname{median}
(SVI_{i,t-1},\ldots,SVI_{i,t-8})
\right].
\]

This is the log of the current weekly count minus the log of the median count over the eight immediately preceding weeks. It is not the median of eight logged values.

The transformation follows Da, Engelberg and Gao (2011). Their original application uses Google search volume. The current study applies the formula to Yandex Wordstat and must not claim that the original paper validates the Russian search phrases or proves that the resulting series measures investor-only attention.

Zero counts are retained in the raw data. If the current count is zero, or if the previous-eight-week median is zero, canonical ASVI is undefined. The primary model does not replace these values with zero, interpolate them, or use log1p. A separately labelled log1p-based measure may be used as a sensitivity check, but it is not the same canonical ASVI.

The primary ASVI is not standardized by each firm's full-sample standard deviation. The coefficient therefore retains the interpretation of a log change relative to the query's own recent baseline.

### 3.4 Why the two existing channels are not combined

The Part 2 audit found a median firm-level rank correlation of approximately 0.505 between the name-based and ticker-only ASVI channels, with 17 firms below 0.30. This does not prove that the channels measure separate populations. It does show that the two series cannot be assumed to be interchangeable or additive.

Accordingly, ticker-only ASVI is estimated separately as a secondary proxy. The current one-query primary specification remains unchanged until a new query basket has been collected, audited and approved.

### 3.5 Planned extension: multiple Russian-language name variants

A later extension will collect several Russian-language phrases for the same issuer. The purpose is to represent the different ways Russian users may refer to a company, including its formal name, short name, common brand form or colloquial abbreviation. The exact phrase list will be registered before new downloads and will not be chosen according to the volatility-model results.

The idea is reasonable as a measurement extension, particularly for smaller companies whose attention may be split across several common names. However, low correlation between two weekly query series does not prove that the series count different searchers or that the underlying query sets are disjoint.

Correlation measures co-movement over time. Low correlation can mean that two phrases capture different types of attention, but it can also result from sparse searches, zero counts, sampling noise, changing popularity, different query intent or weak coverage. For a small company, low counts can make the correlation especially unstable. High correlation is also not proof that one series is included in another; two separate phrases can move together because of the same news.

Yandex's own documentation says that Wordstat displays statistics for queries containing the specified phrase, including possible grammatical forms. In the Wordstat interface, the Top Queries and Regions tabs support operators such as fixing a word form, quotation marks, brackets and grouped alternatives. The Dynamics tab, which provides the historical weekly series, documents support only for the plus operator. Thus, historical weekly query counts cannot automatically be treated as mutually exclusive exact-phrase buckets merely because the submitted strings differ.

The multi-query extension will follow these rules:

1. Each candidate phrase will be stored as a separate series with its exact Wordstat wording, issuer, rationale, export header, region, device filter, weekly dates and source-file hash.
2. Each phrase will receive its own raw weekly count, query-share series, zero-count rate, canonical ASVI series and valid-observation count.
3. Pairwise correlations will be calculated separately for log1p raw counts and for canonical ASVI on overlapping weeks. Both Pearson and Spearman correlations will be reported with the number of overlapping observations and uncertainty intervals. Sparse or zero-heavy series will be labelled as weakly supported rather than interpreted as independent attention.
4. Correlation will be used as a redundancy and co-movement diagnostic only. It will not be described as a test of unique users, user-level duplication or exact query-set overlap.
5. Wordstat's current Top Queries output can help inspect what a phrase captures in the recent period, but it is a recent query list, not a historical query-by-query intersection table. It cannot establish historical non-overlap across the complete weekly sample.
6. Raw weekly counts will not be summed unless the component series can be shown to represent mutually exclusive search-query events. Summing broad phrase counts without such evidence can count the same underlying search query more than once.
7. Wordstat does not supply unique searcher identities in these exports. If one person actually makes two different searches, those are two search events, but the data cannot deduplicate them into one person. The thesis therefore measures search-query activity, not unique people.
8. If multiple phrases are validated as indicators of the same attention construct but their raw counts are not disjoint, the preferred candidate composite is an equal-weight average of the separate query-specific ASVI values, with the number of valid components recorded for every firm-week. This is a normalized attention index, not a total search count. It will be considered only after coverage and measurement reliability have been assessed.
9. If the phrases show very different query intent or insufficient overlapping coverage, they will remain separate channels rather than being forced into one basket.
10. The original single-query result will remain the benchmark. Any approved multi-query index will be reported as a separately versioned measurement specification and estimated without replacing the original result after observing statistical significance.

The proposed multi-query series have not yet been downloaded. No list of the new phrases is included in this draft. The corrected SFIN name query is also still outstanding.

## 4. Measuring intraday price variance

### 4.1 Primary daily estimator

The main outcome is based on the Parkinson (1980) high-low variance estimator. For firm i on trading day d:

\[
Park_{i,d}
=
\frac{\left[\ln(H_{i,d}/L_{i,d})\right]^2}{4\ln 2},
\]

where H and L are that session's daily high and low.

The weekly five-session-equivalent measure is:

\[
Park5_{i,t}
=
\frac{5}{n_{i,t}}
\sum_{d\in t} Park_{i,d},
\]

where n(i,t) is the number of active stock-trading sessions for firm i in week t.

The dependent variable is:

\[
Y_{i,t}=\ln(Park5_{i,t}).
\]

The five-session scaling makes four- and five-session weeks more comparable, provided the week meets the availability rule below. The study also retains strict five-session and unscaled alternatives as robustness checks.

### 4.2 What the outcome measures

Park5 measures within-session high-low variance. It excludes overnight price changes by construction. It is therefore described as intraday or within-session variance, not total weekly realized volatility.

A daily high-low range uses prices from the same trading session. It does not combine a pre-dividend price level and an ex-dividend price level into a single cross-session weekly range. This is the main reason Park5 is preferred over the dividend-adjusted weekly maximum-minus-minimum range for the primary outcome.

This does not mean that dividends have no effect on trading or that Park5 captures overnight risk. It means that the chosen measure addresses a narrower within-session volatility question.

### 4.3 Availability rule

A firm-week is eligible for the primary Park5 sample when:

- the firm has at least four active stock-trading sessions in the week; and
- those sessions are at least 80% of the actual IMOEX market sessions in the same week.

The Part 3 audit found 30,356 firm-week observations under this rule across the 75 firms, before applying the attention, lag and model-completeness conditions. A strict five-session rule is retained as a sensitivity.

Four-session weeks are retained when the market itself operated for four sessions, such as a normal holiday-shortened week. Weeks with fewer than four active stock sessions are not treated as a comparable measure of a five-session-equivalent outcome.

### 4.4 Alternative intraday estimators

Garman-Klass and Rogers-Satchell are used as alternative OHLC estimators. Their independent reconstruction matched the Part 3 output to numerical precision. They are robustness outcomes, not alternatives selected according to which gives the strongest search coefficient.

Yang-Zhang includes overnight price movements. It remains secondary because its overnight component requires separate checks for dividends, long gaps and security-identity transitions.

### 4.5 ROLO

ROLO is retained in the Park5 primary sample. The earlier exclusion in the dividend-adjusted weekly-range work was related to price-basis history and tick-grid concerns. A daily high-low estimator does not bridge the pre- and post-action price levels across sessions, so the absence of a pre-action bar does not automatically invalidate the daily Park5 measure.

The official post-March-2025 tick-size audit did not identify a coarse-grid problem that would justify a blanket ROLO exclusion. Historical official tick metadata before that period are not fully available, so a separate ROLO-exclusion estimate is reported.

## 5. Timing and weekend-session regime

### 5.1 Weekly alignment

Yandex Wordstat weekly Dynamics uses Monday-to-Sunday weeks. The price panel uses the Monday date as the week key. All joins use this Monday key.

For the primary one-week specification, ASVI from the completed search week t-1 is matched to Park5 in the following outcome week t. Lagged ln(Park5) is also included. Same-week ASVI is not used in the primary model.

### 5.2 MOEX weekend trading after March 2025

The Bank of Russia and MOEX define Saturday and Sunday trading as additional sessions assigned to the following Monday's trading day. Thus, after weekend trading began, a Monday-labelled OHLC observation can contain market activity from the preceding weekend. That same weekend belongs to the previous Monday-to-Sunday Wordstat week.

The one-week lag can therefore overlap in real time after the weekend-session rollout. To preserve the strict one-week ordering, the primary t-1 model uses outcome weeks only through the week labelled 24 February 2025.

The full data window is retained in a separately labelled two-week-lag sensitivity, using ASVI t-2. This is a different, longer-horizon timing question and is not used to replace the one-week primary result based on its p-value.

## 6. Primary panel model

The primary model is:

\[
\ln(Park5_{i,t})
=
\alpha_i+\lambda_t+
\beta ASVI_{i,t-1}
+\rho\ln(Park5_{i,t-1})
+\varepsilon_{i,t}.
\]

Here:
- alpha_i is the firm fixed effect;
- lambda_t is the week fixed effect;
- ASVI(i,t-1) is the current Russian-language company/brand-plus-«акции» attention measure;
- ln(Park5(i,t-1)) controls for volatility persistence;
- beta is the primary coefficient of interest.

Firm fixed effects absorb stable differences between firms, such as persistent differences in size, search popularity and average volatility. Week fixed effects absorb shocks shared by firms in the same week, including broad market movements and common attention shocks.

The coefficient is a within-firm, within-week predictive association. It does not identify a market-wide attention effect because common weekly movements are absorbed by the week effects.

### 6.1 Turnover-augmented specification

A nested model adds lagged ruble turnover:

\[
\ln(Park5_{i,t})
=
\alpha_i+\lambda_t+
\beta_V ASVI_{i,t-1}
+\rho_V\ln(Park5_{i,t-1})
+\theta\ln(VALUE_{i,t-1})
+\varepsilon_{i,t}.
\]

VALUE is ruble turnover, not share-count VOLUME. The augmented model tests whether ASVI adds information beyond prior trading activity. Turnover may also be part of the pathway between search interest and volatility, so the baseline remains the primary specification.

No control is added or removed because it produces a smaller p-value.

### 6.2 Inference

The primary covariance estimator is Driscoll-Kraay with a Bartlett kernel and bandwidth of four weekly periods. Sensitivity checks use bandwidth eight and two-way clustering by firm and week.

The model reports the coefficient, standard error, confidence interval, p-value, number of observations, number of firms, number of weeks and within R-squared. Economic interpretation is reported in percentage terms for a doubling of search relative to the preceding eight-week median.

Only the Russian-name ASVI coefficient in the primary Park5 t-1 specification is treated as the single confirmatory test. Ticker-only measures, additional query variants, alternative estimators, the 2022 interaction, sector splits and per-firm models are secondary or exploratory. Holm or Benjamini-Hochberg adjustments are applied within declared secondary testing families.

## 7. The 2022 regime-change test

### 7.1 Motivation and date

The 2022 analysis asks whether the predictive slope between lagged ASVI and Park5 changed after the February 2022 disruption.

The primary break indicator is defined on the outcome-week label:

\[
Post_t =
\begin{cases}
0, & t < 21\text{ February }2022,\\
1, & t \geq 21\text{ February }2022.
\end{cases}
\]

The week labelled 21 February 2022 contains 24 February 2022. It is therefore a transition week, not a clean pre-event or post-event week. The main model includes it under the post indicator, while a sensitivity excludes it and starts Post on 28 February.

The Bank of Russia reports that stock and forward trading stopped on 28 February 2022, that no trades were carried out in those markets from 28 February to 21 March, that stock trading resumed gradually from 21 March, and that the regular trading regime returned on 11 April. The audited Park5 model panel contains no eligible firm-week rows from the week labelled 28 February through the week labelled 28 March. The event week labelled 21 February has four active sessions; the first eligible week after the suspension in this sample is 4 April.

### 7.2 Interaction specification

The slope-change model is:

\[
\ln(Park5_{i,t})
=
\alpha_i+\lambda_t+
\beta ASVI_{i,t-1}
+\gamma(ASVI_{i,t-1}\times Post_t)
+\rho\ln(Park5_{i,t-1})
+\varepsilon_{i,t}.
\]

The pre-break slope is beta. The post-break slope is beta plus gamma. The coefficient gamma measures the change in the within-firm ASVI slope after the break date.

A common Post level dummy is absorbed by week fixed effects and cannot be separately estimated in this model. The interaction does not identify the causal effect of the invasion, sanctions, trading halt or any single geopolitical event. Many economic, regulatory, liquidity and information conditions changed at the same time.

### 7.3 2022 model result

The estimated interaction is negative. The pre-break ASVI slope is positive, while the post-break slope is negative and not statistically distinguishable from zero. The difference between the slopes is statistically distinguishable from zero under DK(4), DK(8) and two-way clustering.

The result is stable when the transition week is excluded and when the period of market suspension and gradual reopening is excluded from the comparison. These tests support a change in the conditional predictive relationship, not a causal attribution to one event.

The 2022 result is secondary to the main one-week predictive model and is interpreted with caution because the market closure creates a calendar gap and the availability rule conditions the sample on firms with sufficient active trading sessions.

## 8. Returns and dividend treatment

Returns are secondary. The v5.3 dividend workbook contains a primary dividend-adjusted weekly-range series for 23,576 firm-weeks across 58 firms. Seventeen firms have uncovered dividend-history years. The workbook distinguishes PAYMENT, NO_PAYMENT and UNKNOWN history states; UNKNOWN is not treated as zero.

The v5.3 return adjustment is not used to replace the main Park5 outcome. The Park5 estimator uses each day's own high and low and does not join price levels across different sessions. The return strand must retain the dividend-history coverage restriction and must not treat a price-only IMOEX index as a total-return market benchmark.

No return is calculated across the YNDX-to-YDEX security identity transition or the long trading interruption in 2022.

## 9. Robustness and secondary analysis

The following checks are reported without changing the primary specification:

1. Eight-week Driscoll-Kraay bandwidth and two-way firm/week clustered standard errors.
2. Garman-Klass and Rogers-Satchell weekly intraday estimators.
3. Strict five-session eligibility and unscaled weekly daily-variance sum.
4. The model excluding ROLO.
5. The nested model with lagged ln(VALUE).
6. Ticker-only ASVI as a separate attention proxy.
7. Full-window ASVI t-2 to avoid weekend-session overlap in the later MOEX regime.
8. The 2022 ASVI-by-Post interaction with alternative handling of the transition and trading-suspension period.
9. A future multi-keyword attention index, subject to the validation protocol in Section 3.5.

Results from firm-level, sector-level and additional lag tests are exploratory. Multiple-testing correction is required before identifying any firm or sector as statistically distinct.

## 10. Interpretation and limitations

The study faces several measurement limits:

- Wordstat counts searches containing query phrases; it does not identify unique searchers.
- A Russian-language company name plus «акции» is a more finance-specific query than a bare ticker, but it still does not prove investor identity or trading intent.
- The current phrase list may miss colloquial names, abbreviations, typos and other Russian-language formulations.
- The current SFIN search phrase has inadequate coverage and requires correction.
- The MOEX weekend-session regime creates overlap between t-1 weekly searches and Monday-labelled daily OHLC after March 2025; the one-week primary window is therefore restricted.
- Park5 excludes overnight jumps by construction.
- The primary model uses within-week cross-firm variation and cannot estimate the effect of common market-wide attention.
- The 2022 break coincides with trading suspension, gradual reopening, sanctions and other regime changes; the interaction is not causal.
- The dividend-adjusted return and weekly-range strand has narrower coverage than the daily intraday-variance panel.
- The study does not perform an out-of-sample forecasting exercise in this methodology draft.

The results must be described as predictive associations and measurement evidence, not causal effects.

## 11. Reproducibility and version control

The V6 research workspace contains:
- frozen input manifests and Part 1–3 audit reports;
- raw Wordstat query audit and query-language registry;
- daily OHLC reconciliation and independent Park5/GK5/RS5 reconstruction;
- MOEX tick-size and session-date audit;
- pre-estimation panel and sample summary;
- Part 4B primary model output;
- Part 4C 2022 interaction script, results and weekly-coverage file;
- a versioned decision register and SHA-256 run manifest.

Source files are not edited in place. New query variants must be registered as new source inputs, hashed and audited before being joined to the panel. They must not overwrite the original Russian-name or Latin ticker channels.

## 12. References

- Da, Z., Engelberg, J., and Gao, P. (2011). “In Search of Attention.” *The Journal of Finance*, 66(5), 1461–1499. https://doi.org/10.1111/j.1540-6261.2011.01679.x
- Parkinson, M. (1980). “The Extreme Value Method for Estimating the Variance of the Rate of Return.” *The Journal of Business*, 53(1), 61–65. https://doi.org/10.1086/296071
- Garman, M. B., and Klass, M. J. (1980). “On the Estimation of Security Price Volatilities from Historical Data.” *The Journal of Business*, 53(1).
- Shu, J., and Zhang, J. E. (2006). “Testing Range Estimators of Historical Volatility.” *Journal of Futures Markets*, 26(3), 297–313. https://doi.org/10.1002/fut.20197
- Driscoll, J. C., and Kraay, A. C. (1998). “Consistent Covariance Matrix Estimation with Spatially Dependent Panel Data.” *The Review of Economics and Statistics*, 80(4), 549–560. https://doi.org/10.1162/003465398557825
- de Haan, E., Lawrence, A., and Litjens, R. (2025). “Measuring Investor Attention Using Google Search.” *Management Science*, 71(7), 6275–6297. https://doi.org/10.1287/mnsc.2022.02174. Its evidence is based on Google and US firms; it motivates caution about ticker-only query measurement but does not validate Wordstat or Russian name-based queries.
- Yandex Wordstat, “Wordstat interface and Dynamics.” https://yandex.ru/support2/wordstat/en/interface/new
- Yandex Wordstat, “Operators.” https://yandex.ru/support2/wordstat/en/content/operators
- Bank of Russia, *Annual Report for 2022*, section “Measures to prevent an uncontrollable crash of the financial market.” https://www.cbr.ru/Collection/Collection/File/46299/ar_2022_e.pdf

---

**Draft status:** The current one-query baseline and the 2022 interaction are specified and estimated. The multi-query basket and corrected SFIN export are planned measurement extensions, not completed data. Any change to the primary attention measure requires a new query-collection audit and a separately versioned model run.


## Data-cleaning update — 15 November 2026 (supersedes earlier sample counts for future estimation)

A subsequent full Wordstat folder audit and eight-year continuity screen has now selected one Russian-language primary phrase for each of 73 firms. SFIN and MRKK are excluded because neither has a stable Russian-name series over the full period. The clean weekly range is 2018-08-27 through 2026-08-31 (419 weeks per firm). The current cleaned panel contains 30,587 Russian-name firm-weeks and a separate 30,587 ticker-only firm-weeks.

The sample and query-selection statements earlier in this Draft 1 reflect the pre-cleaning 75-firm setup. They are retained for historical traceability but are not the final data inputs. All previous Part 4B/4C coefficients are also pre-cleaning and must be re-estimated on the cleaned 73-firm panel before being reported as thesis findings. No re-estimation was undertaken as part of the cleaning task. See 04_design/Keyword_Cleaning_and_8Year_Sample_Checkpoint_2026-11-15.md for the final selected phrases, zero/missingness rules, file moves and validation.


## Part 4D update — re-estimation on the cleaned 73-company sample (15 November 2026)

This update supersedes the earlier data-cleaning note that said the Part 4B/4C models still needed to be rerun. The cleaned panel is now the active estimation input.

### Sample and reproducibility
The model panel contains 73 companies × 419 Monday-labelled weeks (30,587 firm-week rows), from 2018-08-27 to 2026-08-31. SFIN and MRKK are excluded from the Russian-name attention sample because neither has a sufficiently continuous Russian-language name query. The corrected SFIN query and extra Russian synonym basket remain uncollected.

Canonical ASVI was independently recalculated for all 146 retained series from raw weekly counts. The recalculated values matched the saved panel to a maximum absolute difference of 4.44e-16, with identical validity masks. True zero counts remain zeros; undefined canonical log-ASVI values are not imputed. All lag variables were shifted on the complete weekly calendar before model eligibility was applied.

### Re-estimated primary model
The frozen primary specification remains:

ln(Park5_i,t) = firm FE + week FE + beta ASVI_name_i,t-1 + rho ln(Park5_i,t-1) + error.

The primary timing window ends on outcome week 2025-02-24 to avoid overlap between the preceding Monday–Sunday Wordstat week and MOEX weekend sessions assigned to the following Monday.

The clean-sample model contains **22,687 observations, 73 firms and 313 weeks** (2018-10-29 to 2025-02-24). The Russian-name ASVI coefficient is **+0.03107** (DK4 SE 0.02290; p=0.1750; DK8 p=0.1975; two-way cluster p=0.2307). Its approximate 95% DK4 interval is [-0.01383, 0.07596]. A doubling of current search relative to its prior-eight-week median corresponds to +2.18% Park5 variance at the point estimate, with an approximate interval of -0.95% to +5.41%.

The clean-sample one-week primary result is not statistically distinguishable from zero. It does not support a clear short-horizon one-week predictive association; it also does not prove the absence of smaller effects.

### Secondary model evidence
- Lagged turnover augmentation: beta 0.01687, DK4 p=0.4684.
- Excluding ROLO: beta 0.03089, DK4 p=0.1798.
- Full-window ASVI t-2 sensitivity: beta 0.10624, DK4 p=3.22e-7. It remains distinct from the one-week primary timing hypothesis.
- Removing 5/n weekly scaling: beta 0.03061, DK4 p=0.1824.
- Strict five-plus session rule: beta 0.04382, DK4 p=0.0752.
- Garman-Klass outcome: beta 0.07285, DK4 p=0.00162.
- Rogers-Satchell outcome: beta 0.12937, DK4 p=1.30e-7.
- Ticker-only t-1 comparison (excluding YNDX): beta -0.00516, DK4 p=0.7574.

Holm correction across the eight secondary slope specifications leaves t-2, Garman-Klass and Rogers-Satchell statistically detectable. Because the Park5 primary is not significant and the alternative estimators differ, the result is estimator- and horizon-sensitive. Do not describe it as a single robust attention-volatility effect across every approved measure. Only Russian-name ASVI t-1 / ln(Park5) remains the confirmatory primary test.

### Re-estimated 2022 slope interaction
On the same clean 73-firm t-1 sample, the main 2022 interaction (Post from outcome week 2022-02-21) gives pre-break ASVI slope +0.08391, gamma -0.12738 (DK4 p=0.00401), and implied post-break slope -0.04347 (normal-approximation p=0.205). Excluding the transition week (Post from 2022-02-28) gives gamma -0.12772 (p=0.00399); excluding the event/suspension/reopening window through 2022-04-04 (Post from 2022-04-11) gives gamma -0.12676 (p=0.00434). The Holm-adjusted p-value across the three breakpoint definitions is approximately 0.01198.

This is evidence of a change in the within-firm predictive slope, not a causal effect of the invasion, sanctions or trading suspension. The implied post-break slope itself is not statistically distinguishable from zero.

### Files and status
Full model estimates and all covariance results: 02_data_audit/part04d_clean_sample_model_results_v1.json. The full merged panel and per-firm diagnostics are under 05_models/. The detailed checkpoint is 04_design/Part_04D_clean_sample_reestimation_checkpoint_2026-11-15.md; the 12-entry hash manifest is 01_input_manifest/part04d_run_manifest_sha256_v1.csv.

The 74-firm Part 4B/4C coefficients are historical pre-cleaning results and must not be cited as estimates from the cleaned 73-firm sample. The planned extra Cyrillic synonyms and corrected SFIN query remain future measurement extensions. They require separate collection, coverage and redundancy tests, and a new versioned estimation run.


## Part 4E-A update — returns-strand feasibility (15 November 2026)

This update supersedes the earlier general statement that the returns strand was still wholly unevaluated. Part 4E-A has completed a feasibility audit; no returns regression has been estimated yet.

### Sample and dividend-history gate
The audit overlaps the cleaned Wordstat panel (73 firms × 419 weeks, 30,587 cells) with the v5.3 dividend workbook. The annual dividend-history requirement was rebuilt independently for each of the nine calendar years 2018–2026 and agrees exactly with the workbook's Firm_History eligibility flag. **57 of the 73 cleaned firms** pass. The familiar v5.3 figure of 58 firms applies to the original v5.3 universe; its overlap with the cleaned 73-firm Wordstat sample is 57. Unknown or uncovered dividend-history states are not treated as zero.

The v5.3 D_cash_Primary weekly matrix was independently reconstructed from the event register: 31,425 cells, 37 non-zero primary cash cells, zero mismatches and maximum difference 0. Only PAID, known-RUB-amount, primary-qualified events enter the matrix.

### Return variable validation and available sample
The existing RETURN_SAFE series is a price-only log close-to-close return, not a dividend-adjusted return. On 30,100 unflagged paired cells, it matches an independent ln(CLOSE_t/CLOSE_{t-1}) reconstruction with zero mismatches and maximum absolute difference about 1.01e-16.

The inherited v5 cash-adjusted weekly return candidate is:

ln((CLOSE_t + D_cash_primary_t) / CLOSE_{t-1})

It is accepted only when the annual and weekly dividend-history coverage is known, no non-primary/unresolved dividend event or disqualifying corporate-action week is present, close-to-close prices are valid, and the existing return-gap flag is clear. It does not bridge the 2022 interruption or YNDX/YDEX transition.

The resulting cash-adjusted return availability is 23,055 firm-weeks across 57 firms and 414 weeks. After requiring prior-week Russian-name ASVI and the non-overlapping one-week timing cutoff (last outcome week 2025-02-24), the candidate model sample contains **18,196 observations, 57 firms and 327 weeks**, from 2018-10-29 to 2025-02-24. This is suitable for a secondary analysis, not a replacement for the 73-firm Park5 primary.

### Market benchmark limitation
The available IMOEX series is a price index, not a total-return index. A beta-adjusted return using this benchmark must be described only as price-index-adjusted sensitivity, not total-return excess performance. The preferred first return specification, if authorised in Part 4E-B, is a firm- and week-fixed-effects model that absorbs common weekly shocks without requiring index subtraction; the IMOEX price-adjusted measure can remain a separate sensitivity.

### Files and status
Full results and per-firm coverage are in 02_data_audit/part04e_a_returns_feasibility_summary_v1.json and part04e_a_returns_firm_coverage_v1.csv; the sample funnel is part04e_a_returns_sample_funnel_v1.csv; the constructed audit panel is under 05_models/part04e_a_returns_feasibility_panel_v1.csv. The detailed report is 04_design/Part_04E_A_returns_feasibility_checkpoint_2026-11-15.md. The 85-entry run manifest is 01_input_manifest/part04e_a_run_manifest_sha256_v1.csv, verified with zero hash errors.

**Historical stop point after Part 4E-A:** At that checkpoint no returns regression had been estimated. Part 4E-B subsequently completed in the dated addendum below; the cleaned query definitions and corrected SFIN work remain separate and unchanged.


## Update — Part 4E-B secondary returns models and MCFTR benchmark (15 November 2026)

**Status:** Part 4E-B is complete. Returns remain secondary to the 73-firm Park5 volatility analysis.

### Return sample and specification

The clean 73-firm × 419-week attention panel is linked to the validated v5.3 primary-cash dividend matrix. Fifty-seven firms pass the strict 2018–2026 annual dividend-history gate. The Part 4E-A t-1 return candidate had 18,196 observations. Requiring a valid prior-week cash-adjusted return for the dynamic model gives 17,747 observations, 57 firms and 326 weeks, from 2018-10-29 through 2025-02-24.

The company return candidate is:

return_gross_primary(i,t) = ln((CLOSE(i,t) + D_cash_primary(i,t)) / CLOSE(i,t-1))

It is a gross cash-adjusted log-return candidate, not a fully reconstructed reinvested total-return series. It is kept only with known annual and weekly dividend-history coverage, valid close pairs, no return gap, no disqualifying corporate action, and no non-primary/unresolved dividend event week.

The first pooled returns model is:

return_gross_primary(i,t) = firm FE + week FE + beta*ASVI_name(i,t-1) + rho*return_gross_primary(i,t-1) + error(i,t)

DK(4) is primary inference; DK(8) and two-way firm/week clustering are sensitivities.

- DK(4) ASVI beta -0.000323, SE 0.001052, p=0.7591.
- DK(8) p=0.7577.
- Two-way firm/week cluster p=0.7650.
- An ASVI rise of ln(2) corresponds to about -0.022% in weekly log return; approximate 95% interval -0.165% to +0.121%.

This is not evidence of a one-week predictive return association.

### M7-style secondary estimate

A reduced Fama–MacBeth estimator runs cross-sectional OLS by week with a weekly intercept, prior-week ASVI and lagged cash-adjusted return, requiring at least 30 firms. It has 325 weekly coefficients, median 56 firms per week, minimum 41. The mean ASVI slope is +0.000145 (NW(5) SE 0.001230; p=0.9061). This estimator is a secondary comparison, not a replacement for the frozen V6 Park5 primary model.

The weekly intercept absorbs common weekly shocks. The pooled week effects do the same. A standalone common crisis dummy or common market-return series cannot be separately identified in these specifications.

### MCFTR benchmark retrieval and sensitivity

The official MOEX ISS historical endpoint was used to retrieve MCFTR daily history:

https://iss.moex.com/iss/history/engines/stock/markets/index/securities/MCFTR.json

The daily sample has 1,631 observations from 2018-08-27 through 2025-03-03, with zero duplicate dates and zero missing closes. MOEX describes MCFTR as the gross total-return index including constituent capital performance and reinvested dividends; it was first calculated on 30 December 2004.

Daily observations were aggregated to Monday-labelled weekly closes and reindexed to the full Monday calendar before log returns were computed. The 2022 trading closure is not bridged. The weekly data contain 338 closes and 336 non-missing weekly returns. Independent reconstruction from the daily source matches with maximum absolute difference 9.89e-17.

Pre-2022 betas are estimated per firm through outcome week 2022-02-21, with at least 52 valid paired weekly observations. All 57 eligible firms pass; median beta 0.787, range -0.017 to 1.586. The sensitivity outcome subtracts beta times MCFTR weekly return from the cash-adjusted gross return. The beta estimation includes an intercept, but the adjustment subtracts only beta times the benchmark; the pooled firm effects absorb persistent firm return levels. It should not be called a full market-model residual.

- MCFTR-adjusted ASVI beta -0.000170; DK(4) p=0.8741; DK(8) p=0.8712; two-way p=0.8739.
- MCFTR and IMOEX price-only weekly returns correlate 0.99368 over 336 overlapping weeks. Their mean weekly log returns are +0.2247% and +0.0877%, respectively; the mean difference is 0.1370 percentage points. This is not an exact dividend-yield estimate.

### Leave-one-out peer-basket sensitivity

A selected-sample equal-weight return of the other 56 dividend-history-qualified firms is used as a separate leave-one-out comparator, with at least 30 valid peers in a week. It is not a full Russian-market index. Its adjusted panel has 17,721 observations, 57 firms, 325 weeks. ASVI beta -0.000223; DK(4) p=0.8388; DK(8) p=0.8380; two-way p=0.8411.

MCFTR may include the focal firm when it is an index constituent. Audited historical MCFTR constituent weights were not available in the supplied V6 inputs, so a historical test excluding the heaviest constituents was not run. The peer-basket sensitivity excludes the focal firm but is not a reconstructed leave-one-out MCFTR.

### Decision and limits

- The first returns model uses firm and week fixed effects; the weekly Fama–MacBeth intercept also absorbs common shocks. Do not add a common Crisis dummy to either model.
- No separate dividend dummy is added to the baseline return model because the return is already cash-adjusted using the verified primary cash matrix, and non-primary/unresolved dividend-event weeks are excluded.
- Sector sanctions are not common shocks if they affect only a subset of firms. They require an exposure interaction or a sector-time design; they were not tested in Part 4E-B.
- The primary cash-adjusted company return is not a fully reconstructed gross total-return series, so the MCFTR beta-adjusted sensitivity is informative but not a perfect matching total-return comparison.
- No per-firm M1/M2 models were run in this chunk. Their later design can compare the lagged Crisis dummy with leave-one-out peer volatility and can use leave-one-out peer attention/volatility measures. Sector-specific and firm-specific event exposures must remain distinct from common weekly shocks.
- All return results are statistically inconclusive. Do not claim evidence that ASVI predicts next-week returns.

Checkpoint: 04_design/Part_04E_B_returns_models_checkpoint_2026-11-15.md. Results, raw/weekly MCFTR data, model panel, Fama–MacBeth coefficients, beta files and the 14-entry zero-error SHA-256 manifest are listed in that checkpoint. Original source files remain read-only.

---

## Amendment — Part 4E-B v2 and V5.0 design considerations (15 November 2026)

Part 4E-B v2 independently reran the secondary return estimates on the Part 4E-A feasibility panel. The dynamic cash-adjusted return sample remains 17,747 observations, 57 firms and 326 weeks. The firm/week-FE ASVI coefficient is -0.000323 under DK(5) (SE 0.001057, p=0.7602); DK(4), DK(8) and two-way clustering give the same coefficient and p-values 0.7591, 0.7577 and 0.7650. The reduced M7-style Fama–MacBeth mean slope is +0.000145 (NW5 p=0.9061). MCFTR-adjusted and leave-one-out peer-adjusted sensitivities are also inconclusive. A conservative 56-firm sensitivity excluding RNFT is inconclusive (ASVI beta +0.000143; DK5 p=0.8896). Full details and sample counts are in the dated Part 4E-B v2 checkpoint and v2 result JSON.

### Covariance bandwidth rule

V2 reports DK(5) because the predecessor V5.0 plug-in rule yields five weekly lags at the present sample length. DK(4) is retained to make the new rerun directly comparable with the already completed V6 outputs. DK(8) and two-way firm/week clustering remain sensitivities. Before rerunning the core Park5 models, standardise the V6 reporting rule explicitly. Do not silently overwrite Part 4D or imply that it used DK(5).

### Version disclosure and change log

Methodology V5.0 is a predecessor, not the controlling V6 specification. A formal thesis change log must document the reason for the transition from weekly dividend-adjusted high-low range to daily Park5, from summed ticker-plus-name attention to a standalone Russian-name primary channel, and from the former broad baseline control set/evidence architecture to the more parsimonious V6 primary panel design. The thesis must state that earlier design versions and results had been inspected and therefore the analysis is not preregistered. Any later changes must be justified by measurement, calendar alignment, identification or parsimony, not by coefficient size or statistical significance.

### Null-result detection limit

For the clean V6 Park5 t-1 primary model, the DK(4) standard error is 0.02290. A rough 80%-power minimum detectable coefficient is 2.8 × 0.02290 ≈ 0.0641. For an ASVI increase of ln(2), that translates to about a 4.5% change in Park5 variance. Report this as an approximate detection limit alongside the statistically inconclusive estimate; it does not establish that smaller effects are absent and should be qualified if finite-sample or multiplicity adjustments are made.

### Next volatility diagnostics

The next empirical chunk should complete the two-by-two comparison of one- and two-week attention lags on both the pre-weekend sample ending 24 February 2025 and the full available sample. This separates lag length from sample-period extension. The full-window t-1 cell overlaps the post-March-2025 weekend-session allocation and must be presented only as a timing-overlap sensitivity, not as a clean one-week predictive model.

A separate overnight-inclusive robustness outcome should be considered: sum of squared daily total-return/log returns. It must be built from daily returns with dividend and corporate-action treatment validated; it is a different outcome from Park5, GK5 and RS5, all of which measure within-session ranges.

### Sample and event-control corrections

The cleaned 73-firm Wordstat panel includes ROLO. ROLO is not among the 57 dividend-history-qualified return firms. V6 retains ROLO in the Park5 sample because the current daily within-session Parkinson outcome does not mechanically join price levels across its old/new basis; an ROLO-exclusion estimate remains a sensitivity. The previous V5 weekly-extrema/coarse-grid exclusion must not be mechanically applied after the outcome definition changed.

For company and sector models, retain audited company-specific sanctions and sector exposure interactions as predeclared variants when the event dates and affected exposure are supported. Common market-wide event dummies are absorbed by week fixed effects or weekly cross-sectional intercepts. Sector-level events require a differential exposure term or a sector-by-time design. Do not add controls solely to improve significance.

For the cash-adjusted return baseline, no separate dividend dummy is added to repeat the same dividend correction already embedded in primary cash; unresolved and non-primary dividend event weeks remain excluded. For Park5, overnight ex-dividend price drops do not mechanically enter the within-session daily range, though dividend events can still be tested as actual intraday-event heterogeneity or in the overnight-inclusive return sensitivity.

### Dividend share-class check

The Part 4E-B v2 audit confirms that all 546 canonical dividend rows attached to the 57 eligible firms are ordinary-share (ORD) records. No preferred-share record enters the eligible cash ledger. RNFT is an exception in the workbook's firm-history classification: it is labelled preferred-only/other-class and has no canonical cash event row. The listed RNFT instrument is ordinary/common stock; the workbook source notes indicate the historical payments described for RNFT relate to non-traded preferred shares. V2 therefore retains the 57-firm annual-gate result and reports a separate 56-firm sensitivity excluding RNFT. It does not alter the source workbook.

### Literature completion

Before thesis submission, verify and include full bibliographic details for Bazhenov and Fantazzini (2019), Fantazzini and Kurbatskii (2026), Andrei and Hasler (2015), and Vlastakis and Markellos (2012) wherever they are cited. Distinguish directly inspected evidence from abstract-only or secondary-source evidence; do not invent page ranges or publication status.

**Current status:** Part 4E-B v2 is complete. No per-firm M1/M2 models, sector-sanction interactions or dividend-event heterogeneity models have been run. The next authorised chunk should be the Park5 lag/sample 2×2 diagnostic. Original source data and the v5.3 dividend workbook remain read-only.


---

## Amendment — Part 4D lag × sample-window 2×2 diagnostic (15 November 2026)

The lag-versus-window diagnostic has now been completed on the frozen 73-firm Part 4D model panel. All four cells use the same Park5 outcome, lagged ln(Park5) control, firm and week fixed effects, and four-active-session / 80%-IMOEX eligibility rule. The two dimensions varied are the Russian-name ASVI lag (t−1 or t−2) and the outcome sample window (ending 24 February 2025 or the full available window through 31 August 2026).

| Specification | N | Firms | Weeks | ASVI beta | DK5 SE | DK5 p | 95% DK5 CI | DK4 p | DK8 p | Two-way p |
|---|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|
| t−1, clean window | 22,687 | 73 | 313 | +0.03107 | 0.02333 | 0.18293 | [−0.01465, 0.07679] | 0.17502 | 0.19753 | 0.23070 |
| t−1, full window | 28,294 | 73 | 390 | +0.02465 | 0.02301 | 0.28420 | [−0.02046, 0.06975] | 0.27319 | 0.30119 | 0.32134 |
| t−2, clean window | 22,622 | 73 | 312 | +0.11207 | 0.02286 | 9.50e−7 | [0.06727, 0.15688] | 4.82e−7 | 3.50e−6 | 1.15e−9 |
| t−2, full window | 28,230 | 73 | 389 | +0.10624 | 0.02130 | 6.16e−7 | [0.06449, 0.14799] | 3.22e−7 | 1.82e−6 | 7.42e−9 |

The V5.0 bandwidth formula floor(4*(T/100)^(2/9)) gives DK(5) in each cell. DK(4) is retained to compare with the original frozen Part 4D inference; DK(8) and two-way firm/week clustering are sensitivity checks. The clean t−1 model reproduces the original Part 4D DK(4) beta, standard error and p-value to machine precision. The original Part 4D model and report were not overwritten.

### Interpretation and limitation

The t−1 estimate remains small and statistically inconclusive in both windows. The t−2 estimate is positive and statistically detectable in both windows, and its coefficient is similar in the clean and full samples. Thus the observed difference appears more consistent with lag choice than with extending the sample. This is a descriptive comparison of separate regressions, not a formal test that the t−2 coefficient differs from t−1.

The full-window t−1 cell is a timing-overlap sensitivity only. Post-March-2025 Monday-labelled OHLC can include weekend sessions that overlap the preceding Monday–Sunday Wordstat week. It must not be described as a clean predictive test. The original clean-window t−1 Park5 specification remains the sole confirmatory primary model and is still statistically inconclusive. The t−2 finding is secondary and must not replace the primary result based on significance.

Independent QA reconstructed all four sample sets and exact ticker-week memberships, independently re-estimated every covariance result, and passed. The 10-entry SHA-256 manifest has zero mismatches. Detailed checkpoint and result files are listed in CURRENT_HANDOFF_STATUS.md and the dated Part 4D 2×2 checkpoint.

**Current status:** Chunk 1 is complete. The next planned chunk is an overnight-inclusive sum-of-squared daily total-return/log-return outcome, but it requires daily dividend and corporate-action validation first and must wait for explicit authorisation. No per-firm M1/M2 models have been started.


---

## Amendment — Part 4F overnight-inclusive daily total-return volatility sensitivity (15 November 2026)

A secondary overnight-inclusive outcome was constructed as the weekly sum of squared valid daily close-to-close gross log total returns. The daily return is ln((basis-adjusted traded close + verified primary cash dividend) / previous active close). Confirmed split/consolidation factors are applied to the effective-date close; the recorded dividend per-share amounts remain on their as-traded basis. Returns over seven calendar days are omitted. The outcome includes overnight/weekend moves between traded closes but is not high-frequency intraday realized variance. Park5 remains the primary outcome.

The daily sensitivity uses the 57 firms passing the v5.3 annual dividend-history gate, not all 73 firms in the primary attention/Park5 sample. Its matched clean t−1 panel has 17,005 observations, 57 firms and 313 weeks (2018-10-29 to 2025-02-24). The daily-RV ASVI coefficient is +0.016854 (DK5 SE 0.034732; p=0.627507; 95% CI [−0.051225, +0.084933]); DK4 p=0.623078, DK8 p=0.635066 and two-way p=0.607593. Park5 on the identical matched observations gives beta −0.029209 (DK5 p=0.246127). Both are inconclusive; the matched-sample Park5 estimate is a comparator, not the 73-firm confirmatory result.

The event audit found 37 primary cash events, all paid, qualifying and positive-amount with an active ex-date bar; 475 nonprimary/unresolved event weeks were excluded. The three corporate actions relevant to the 57 firms were confirmed: GMKN 100:1 split, PLZL 10:1 split and VTBR 5000:1 consolidation. The supplemental audit found 71 firm-weeks with at least one daily interval longer than seven calendar days; all 71 are excluded from the daily-RV eligible sample (69 have the upstream gap flag and the other two fail the minimum daily-count rule). Price-only daily log returns compound to weekly RETURN_SAFE on 22,530 eligible no-dividend/no-action firm-weeks with zero mismatches (maximum absolute difference 5.01e−16).

Independent reconstruction QA passed; all 114,578 saved daily rows and weekly aggregation were reproduced; the 74-entry original Part 4F manifest and 13-entry supplemental manifest have zero hash mismatches. The source workbook remains unchanged.

**Scope correction:** ROLO is in the cleaned 73-firm attention/Park5 sample but is not one of the 57 dividend-history-qualified return firms. Its T3 action week is therefore not a Part 4F exclusion. The original Part 4F v1 checkpoint sentence suggesting otherwise is superseded by the v1.1 supplemental scope-correction addendum. Do not conflate the 57-firm daily-return sensitivity with the 73-firm Park5 primary analysis.

Detailed result and supplemental audit files are listed in CURRENT_HANDOFF_STATUS.md and the dated Part 4F addendum. The next planned chunk is Chunk 3, per-firm volatility models (M1); no per-firm models have been started.


---

## Amendment — Part 4G firm-specific volatility slopes (M1) (15 November 2026)

The exploratory firm-level volatility analysis is estimated as a joint heterogeneous-slope panel so that firm-specific ASVI slopes can be recovered while retaining the common time effects of the primary design:

`ln(Park5_i,t) = alpha_i + lambda_t + beta_i ASVI_name_i,t-1 + rho_i ln(Park5_i,t-1) + error_i,t`

Both the ASVI and lagged-volatility coefficients are allowed to vary by firm. The clean one-week sample is the same frozen Part 4D sample: 22,687 observations, 73 firms and 313 weeks from 29 October 2018 to 24 February 2025. DK(5) is the primary covariance estimator, with DK(4) and DK(8) as bandwidth sensitivities. Holm and Benjamini–Hochberg corrections are applied to the 73 DK(5) ASVI tests.

Ten firms have raw DK(5) p < 0.05. Two survive Holm (PHOR and SIBN); five survive BH (KAZT, PHOR, RTKM, SBER and SIBN). The coefficients are mixed in sign: 40 positive, 33 negative, median +0.00665. These are exploratory firm-level conditional associations. They do not replace the sole confirmatory pooled Park5 t−1 result, which remains statistically inconclusive.

A two-way firm/week clustered covariance was calculated during development but excluded from the reporting table and not interpreted. Each firm-specific ASVI interaction regressor is supported by only one entity cluster, so the firm-cluster component does not have many clusters contributing to each coefficient; it generated implausibly tiny standard errors for some slopes. Report DK(5), DK(4) and DK(8) only for these heterogeneous firm-specific slopes.

A simpler standalone OLS/HAC regression for each firm, without week fixed effects, is retained as a diagnostic version only. Because those regressions cannot absorb common weekly market shocks, they are not the main M1 estimates. The clean reporting results and independent QA are documented in the dated Part 4G v2 checkpoint and v2.1 QA/inference addendum. Independent re-estimation reproduced all reported coefficient, SE, p-value and CI values to a maximum absolute difference of 1.11e−16; exact sample membership and Holm/BH corrections also passed. The original Part 4D panel remains unchanged.

No per-firm return M2 model, Granger test, peer model or sanctions interaction has yet been estimated.


---

## Amendment — Part 4H firm-specific cash-adjusted return slopes (M2) (15 November 2026)

The exploratory M2 analysis estimates firm-specific ASVI-return slopes jointly while retaining firm and week fixed effects:

`return_gross_primary_i,t = alpha_i + lambda_t + beta_i ASVI_name_i,t-1 + rho_i return_gross_primary_i,t-1 + error_i,t`

The dependent variable is the inherited gross primary-cash-adjusted weekly log-return candidate, ln((weekly CLOSE + D_cash_primary)/prior weekly CLOSE). It is not a fully reconstructed dividend-reinvestment total-return series. The model sample includes only the 57 firms passing the annual dividend-history gate (17,747 observations, 57 firms and 326 observed weeks, 29 October 2018 to 24 February 2025). The firm-specific ASVI and lagged-return slopes vary by ticker; both firm and week fixed effects are retained.

Inference uses calendar-week-aware Driscoll–Kraay Bartlett DK(5), with DK(4) and DK(8) bandwidth sensitivities. Five whole Monday weeks in the 331-week calendar have no eligible return observations; these periods are retained as zero score rows in the long-run covariance rather than compressed out. The bandwidth rule implies five weekly lags. Holm and Benjamini–Hochberg corrections are applied to the 57 DK(5) firm-specific ASVI tests.

Four firms have raw DK(5) p < 0.05 (CBOM, GMKN, RNFT and SIBN); none survives Holm or BH. A conservative 56-firm sensitivity excluding RNFT has three raw p < 0.05 (CBOM, GMKN and SIBN), but again none survives either correction. The pooled Part 4E-B return model remains statistically inconclusive (ASVI beta −0.000323; DK(5) p=0.7602). Thus no firm-specific return relationship should be claimed from these exploratory regressions.

Two-way firm/week cluster p-values are not interpreted for these ticker-specific ASVI interaction regressors, because each interaction is active in one entity cluster only. The main and RNFT-excluded panels were independently re-estimated; all coefficients, standard errors, p-values, confidence intervals and multiple-testing corrections reproduced to a maximum absolute difference below 1.2e−16. The exact sample membership and full-calendar lag alignment also passed. The detailed checkpoint and QA addendum are listed in CURRENT_HANDOFF_STATUS.md.

No Granger/lead-lag tests, peer-attention/peer-volatility models or sanctions/sector interactions have been run yet.


---

## Part 4I amendment — Granger and lead-lag tests (15 November 2026)

Part 4I adds exploratory Granger-style temporal-predictability tests. It does not change the confirmatory V6 one-week Park5 specification. Lag orders are p=1,2,4. All lags are generated on the complete 419-week Monday calendar before observations are filtered; missing weeks and the 2022 suspension are never compressed into adjacent observations. The clean outcome window ends 24 February 2025 to avoid the later MOEX weekend-session timing overlap.

The pooled specification includes firm and week fixed effects and both the dependent variable's own lags and the cross-variable lags. The null is that all p cross-variable lag coefficients are jointly zero. The reverse direction is tested separately. Pooled inference uses calendar-week-aware Driscoll–Kraay Bartlett covariance, DK(5) primary and DK(4)/DK(8) sensitivities. Pooled level hypotheses are corrected as one family of 12 outcome × direction × lag tests; the six first-difference Park5 sensitivity hypotheses are corrected separately.

The pooled level tests find no ASVI → ln(Park5) predictive content at p=1 (DK5 p=.1780; Holm p=.5448), but do find joint incremental content at p=2 (p=.000260; Holm=.002082) and p=4 (p=5.38e−9; Holm=4.84e−8). Reverse Park5 → ASVI tests are significant at all three lag orders. For the 57-firm cash-adjusted return candidate, ASVI does not predict returns at p=1,2,4; reverse Return → ASVI is significant under BH but not Holm. The outcome remains a gross primary-cash-adjusted return candidate, not a fully reconstructed reinvestment total-return series.

The first-difference Park5 sensitivity finds ΔASVI → Δln(Park5) at p=1,2,4 after Holm adjustment. It is a separate transformed-outcome sensitivity and does not replace the level-based confirmatory result. Unit-root diagnostics were run on each firm's longest uninterrupted nonmissing weekly segment without compressing gaps: ASVI results were supportive of stationarity, but ln(Park5) diagnostics were mixed (ADF rejected in 63/73; KPSS rejected stationarity in 23/73). Cash-adjusted return test coverage was limited to 41/57 sufficiently long continuous series. These are diagnostics, not a definitive panel unit-root analysis.

Firm-specific bivariate tests include an intercept, post-21-February-2022 indicator, own-variable lags and cross-variable lags, with calendar-week-aware Newey–West Bartlett five-week covariance. They do not include week fixed effects and are therefore exploratory; they cannot absorb all common weekly market shocks. Holm and BH are applied within each outcome × transformation × direction × lag-order family. For level Park5, 6/73, 3/73 and 1/73 firms survive Holm in the ASVI → Park5 direction at p=1,2,4; reverse-direction discoveries are more numerous. No firm-specific ASVI → return test survives Holm or BH at any lag order. Firm results must not be interpreted as established company-level effects.

Independent QA re-estimated all 18 pooled models and 1,218 firm-specific models. Exact pooled sample memberships, coefficients, DK(4/5/8) results, calendar-aware Newey–West statistics and Holm/BH corrections reproduced to numerical precision. The maximum pooled p-value difference was 1.39e−16; the maximum firm-specific p-value difference was 7.22e−16. QA status PASS. Detailed methods, tables and reproducibility paths are in 04_design/Part_04I_Granger_and_Lead_Lag_Checkpoint_2026-11-15_v1.md.

All Granger results remain in-sample predictive associations, not structural causal effects. No out-of-sample forecast exercise was conducted. The primary pooled one-week Park5 result remains statistically inconclusive; longer lag and firm-level findings remain exploratory.


---

## Part 4J amendment — Sector peer attention and peer volatility (16 November 2026)

Part 4J adds a secondary/exploratory sector-peer extension to the 73-firm V6 Park5 design. It tests whether the prior-week search attention and within-session volatility of other firms in a focal firm's saved sector add predictive content for the focal firm's next-week ln(Park5), beyond the focal firm's own lagged ASVI and volatility.

Peer ASVI is the equal-weight arithmetic mean of other firms' name-query ASVI in the same saved sector and week, excluding the focal ticker. Peer volatility is the equal-weight mean of other eligible firms' ln(Park5) in the same sector-week, also excluding the focal ticker. A peer measure is defined only when at least two other firms have valid values. Peer volatility contributors must satisfy the frozen 80% market-session eligibility rule. All peer values are first computed on the complete 419-week Monday grid and then shifted by one full week before joining the outcome. Historical market-cap weights are unavailable, so no value weighting is used.

The 73 sampled firms occupy 13 saved sector labels. Ten sector groups have at least three firms; three are singletons (Diversified, Industrial and Insurance). The singleton firms cannot have two same-sector peers and are excluded from the peer model. The common peer sample contains 70 firms across ten sectors, with 21,728 observations and 313 observed weeks from 29 October 2018 to 24 February 2025. The baseline 73-firm clean sample remains 22,687 observations and is estimated separately. The attention-only peer sample has 21,748 observations; the eligible peer-volatility and common nested-model sample has 21,728 observations.

The main M3 two-way-FE specification includes own ASVI(t−1), leave-one-out peer ASVI(t−1), leave-one-out peer ln(Park5)(t−1), own ln(Park5)(t−1), firm effects and week effects. DK(5) calendar-week-aware Driscoll–Kraay covariance is primary; DK(4), DK(8) and two-way firm/week clustering are sensitivities. The two peer coefficients in M3 are the predeclared peer-effect family and receive Holm/BH corrections. M1 and M2 add each peer variable separately on the same common sample; M0_73 and M0_70 are baseline comparators.

M3 results: peer ASVI beta +0.00479 (DK5 SE 0.04076; p=.9064; 95% CI [−0.07510,+0.08469]); peer ln(Park5) beta +0.02054 (DK5 SE 0.01896; p=.2787; 95% CI [−0.01662,+0.05771]). Their joint Wald test is χ²(2)=1.796, p=.4074. Neither peer coefficient survives Holm or BH. Peer-ASVI p-values remain above .90 under DK(4), DK(5), DK(8) and two-way clustering; peer-volatility p-values remain above .26 across the same covariance choices. In the separate M1 and M2 component specifications, peer ASVI has p=.4061 and peer volatility p=.1907.

The own-ASVI baseline coefficient remains close to the original value: +0.03107 in the 73-firm model (calendar-aware DK5 p=.1780), +0.03090 in the 70-firm common peer sample (p=.1893), and +0.03021 in M3 (p=.1961). Therefore the peer additions do not materially change the inconclusive one-week own-attention result. They do not provide statistically detectable pooled evidence of sector peer-attention or peer-volatility effects.

Independent QA rebuilt the peer columns directly from the frozen Part 4D panel, ran 592 direct leave-one-out checks, verified exact membership for all five models and independently re-estimated all coefficients, standard errors, p-values, confidence intervals and multiple-testing corrections. The largest coefficient/statistic differences were below 1e−13, peer-column differences below 1.8e−15, sample membership matched exactly and Holm/BH corrections matched exactly. QA status PASS. The original source panel remains unchanged. Full output and paths are in 04_design/Part_04J_Peer_Attention_and_Peer_Volatility_Checkpoint_2026-11-16_v1.md.

Interpretation remains limited: these are in-sample conditional associations, not causal spillovers. Sector-specific news or exposures may drive both peer measures and focal volatility. Only ten sector groups contribute, the peer sample excludes three singleton sectors, and the measures are equal-weighted. This Part 4J peer-attention/peer-volatility measure is distinct from the earlier Part 4E-B all-sample leave-one-out return benchmark. It must not be called the same peer variable or used to imply that the prior return sensitivity was a sector model.

The confirmatory 73-firm one-week Park5 result remains statistically inconclusive. Part 4J is secondary and does not replace it. No sanctions/sector-exposure interaction has been started; await explicit user instruction before proceeding.


---

## Part 4K amendment — Direct L1 designation history and sector peer-sanctions concentration (16 November 2026)

Part 4K adds an exploratory firm- and sector-exposure interaction stage to the V6 Park5 model. The treatment source is the 16 November session-audited workbook named sunctions list.xlsx (source-file SHA-256 5ccf6884c07ca71adfa7ebf400b149403525466800a32212706e5ad35f78202d). The workbook records 85 direct designation rows from US OFAC, EU consolidated financial sanctions and UK Sanctions List sources, classifying 72 L1 rows and 13 L2 rows. It does not infer direct company exposure from ownership. Its own QA sheet reports 10/10 checks as of 31 October 2026. This session independently rebuilt the L1 and L1+L2 matrices from its row-level designation table; both matched their 419-week workbook matrices cell by cell with zero mismatches. The session did not independently re-download every underlying official-list locator, so the source workbook's external evidence audit date and scope remain explicit limitations.

The primary treatment A is a cumulative ever-direct L1 designation-history indicator, first switched on in the Monday week of the recorded announcement and then left on. It measures history of direct L1 designation, not current legal in-force status. G is a broader L1+L2 history sensitivity and is not equivalent to L1. E is a separate active-L1 jurisdiction-count sensitivity that respects recorded removal weeks. No ownership-implied exposure is coded. “No direct listing found in these three lists” is not described as “unsanctioned”.

At the clean V6 outcome cutoff of 24 February 2025, 29 of the sampled 73 issuers have an L1 designation history. Two first designations predate the panel (MSTT and RUAL), so their onset is left-censored; 27 sampled issuers first switch into L1 during the observed window. Nine other sample issuers have first L1 designations after the outcome cutoff. Under broader L1+L2 history, 34 firms are designated by the cutoff. The exact Part 4D 73-firm base sample is 22,687 observations, 73 firms and 313 weeks (29 October 2018–24 February 2025). Leave-one-out sector-peer-share models use 21,748 observations, 70 firms and 313 weeks. Three single-company sector labels (Diversified, Industrial and Insurance) cannot have two other same-sector peers and do not contribute to the peer-share models.

All treatment and peer-share variables are shifted on the full 419-week Monday calendar before being joined to next-week ln(Park5). The peer L1 share is the equal-weight fraction of other issuers in the same saved V6 sector that have direct L1 designation history by the previous week, excluding the focal issuer and requiring at least two peers. It is a sample-composition measure, not an official sector or economic exposure metric.

M3 is the main combined two-way-FE specification: own ASVI(t−1), own L1 history(t−1), sector peer L1 share(t−1), both ASVI interactions, own ln(Park5)(t−1), firm effects and week effects. Calendar-week-aware Driscoll–Kraay Bartlett DK(5) is primary; DK(4), DK(8) and two-way firm/week cluster inference are sensitivities. The two M3 ASVI interaction coefficients form one Holm/BH family.

M3 results: own L1 history × ASVI beta −0.01092 (DK5 SE 0.04687; p=.8158; 95% CI [−0.10279,+0.08095]); sector peer L1 share × ASVI beta −0.08861 (DK5 SE 0.05728; p=.1219; 95% CI [−0.20087,+0.02366]). Their joint test is Wald χ²(2)=2.774, p=.2498. Holm/BH adjusted p-values are .8158 for the own-L1 interaction and .2438 for the peer-share interaction. Neither is statistically significant. Both are also inconclusive under DK4, DK8 and two-way clustering. The M3 own-ASVI coefficient is +0.04459 (DK5 p=.0960); the original confirmatory Part 4D result remains unchanged (beta +0.03107; DK4 p=.1750).

The sector peer L1 share main effect is nominally significant under DK5 (beta +0.09677, p=.0033), but not under two-way firm/week clustering (p=.3464), so it is not treated as robust. The own L1 main effect is inconclusive (DK5 p=.0701; two-way p=.4488). The component own-L1 interaction model on 73 firms is −0.03919 (DK5 p=.4128); the peer-share component interaction model is −0.09527 (DK5 p=.0979). The active-L1-jurisdiction-count interaction sensitivity is −0.02139 (DK5 p=.3865). In the broader L1+L2 sensitivity, the own interaction is −0.08493 (DK5 p=.0623; DK8 p=.0553; two-way p=.0687), which does not reach 5% under any reported covariance; the peer-share interaction is −0.03267 (DK5 p=.7253). No sensitivity is promoted to the primary result based on its p-value.

Independent QA reconstructed A, G, active L1 counts and the leave-one-out sector variables directly from the workbook rows and independently re-estimated all eight models. It passed 740 direct leave-one-out checks, exact sample membership for all eight models and source/matrix checks. Peer-variable differences were below 2.3e−16; coefficient and inference differences were below 4e−12; Holm/BH adjustments matched within 1.2e−16. QA status PASS. The frozen Part 4D panel remains unchanged. Detailed methods and all sample/output paths are in 04_design/Part_04K_Sanctions_and_Sector_Exposure_Checkpoint_2026-11-16_v1.md.

These are conditional observational associations, not causal effects of sanctions. A does not equal current in-force status; E is the active-count sensitivity. The peer-share is a 73-sample concentration measure, not sector-wide economic exposure. The workbook's 31 October 2026 external QA record is acknowledged; this session independently rebuilt workbook matrices and models but did not fetch every official source locator again. Part 4K is secondary/exploratory. It does not change the confirmatory one-week Park5 result, and the existing generic Part 4C post-2022 break remains a different question.


---

## Part 4L amendment — Thesis-wide results synthesis and version reconciliation (16 November 2026)

Part 4L integrates completed V6 Parts 4B–4K. It does not estimate another model or alter source panels. Its checkpoint is 04_design/Part_04L_Thesis_Wide_Synthesis_and_Consistency_Audit_2026-11-16_v1.md; the machine-readable master matrix, version bridge and audit are in 02_data_audit/part04l_master_results_matrix_v1.csv, part04l_version_reconciliation_v1.csv and part04l_synthesis_audit_v1.json.

**Authoritative primary finding:** the current cleaned Part 4D 73-firm primary model has 22,687 observations over 313 weeks (29 October 2018–24 February 2025). ASVI_name(t−1) beta is +0.03107, DK(4) SE 0.02290, p=.1750, 95% coefficient interval [−0.01383,+0.07596]. A doubling of search relative to the preceding-eight-week median corresponds to an estimated +2.18% in Park5 variance, with a 95% interval of −0.95% to +5.41%. The post-estimation 80% detectable-effect benchmark is 4.55%, not prospective power. The one-week pooled result is positive but statistically inconclusive.

The clean two-week ASVI lag is positive and statistically detectable (beta +0.11207, DK(5) p=9.50e−7, N=22,622, 73 firms, 312 weeks), but is a separate horizon and not a formal test that the t−2 coefficient exceeds the t−1 coefficient. Garman–Klass and Rogers–Satchell alternatives are detectable in the declared eight-member secondary Part 4D Holm family (Holm p=.00975 and 1.04e−6); these estimator-specific secondary results do not replace Park5 as the one confirmatory outcome.

The cleaned 73-firm 2022 interaction shows a change in ASVI slope across the broad regime break: gamma −0.12738, DK(4) p=.00401, Holm across three declared break/suspension-window definitions p=.01198. The implied post-break slope is −0.04347, DK(4) p=.20485. Therefore report a slope change, not a significant negative post-break attention effect and not a causal effect of war, sanctions, market suspension or reopening.

The 57-firm dividend-history-qualified gross primary-cash-adjusted weekly return candidate has ASVI beta −0.000323 (DK(5) p=.7602; N=17,747); it is not a fully reconstructed dividend-reinvestment total-return index. The separate 57-firm overnight-inclusive daily-return sum-of-squares volatility proxy has beta +0.01685 (DK(5) p=.6275; N=17,005). Both are inconclusive and use a narrower population than the 73-firm Park5 model.

Exploratory firm-specific Park5 slopes produce 10 raw discoveries among 73 tests, 2 Holm and 5 BH; the Holm discoveries are PHOR (beta −0.370) and SIBN (beta −0.493). These are firm-specific conditional associations, not evidence that the pooled market-wide slope is significant. Firm-specific return slopes produce 4 raw discoveries among 57 tests and zero Holm/BH discoveries.

Pooled Park5 Granger-style levels tests show no ASVI→Park5 predictive increment at lag order 1 (p=.1780; Holm=.5448), but cross-lag blocks at orders 2 and 4 survive Holm (p=.000260 and 5.38e−9). Reverse Park5→ASVI tests survive Holm at lag orders 1, 2 and 4. These are temporal predictive-content tests in both directions, not structural causation or out-of-sample forecast improvement. First-difference sensitivity tests for ΔASVI→Δln(Park5) at lag orders 1, 2 and 4 also survive their separate Holm family. For cash-adjusted returns, ASVI→return is inconclusive at all tested orders; return→ASVI survives BH but not Holm.

Part 4J's combined sector peer-attention/peer-volatility model (70 firms, N=21,728) finds no detectable peer-ASVI term (beta +0.00479, DK5 p=.9064) or peer-volatility term (beta +0.02054, p=.2787); joint p=.4074. Part 4K's combined own-L1 and sector peer-L1 interactions (70 firms, N=21,748) are also inconclusive: own L1×ASVI beta −0.01092 (DK5 p=.8158), peer L1 share×ASVI beta −0.08861 (p=.1219), joint p=.2498. The sanctions/peer share is sample-based concentration, not official economic exposure.

The current authoritative primary sample is the clean 73-firm Part 4D panel: SFIN and MRKK are excluded from the Russian-name attention series; ROLO is retained, with an exclusion sensitivity. Earlier 74-firm Part 4B/4C estimates are historical and superseded. The earlier Part 4C 74-firm 2022 interaction is likewise superseded by the cleaned Part 4D interaction. Returns remain a 57-firm selected subset. The 4J common peer-ASVI/peer-volatility model uses 21,728 rows; 4K uses 21,748 rows because the sanctions peer predictor does not require peer Park5 availability. These sample counts differ for a reason.

Part 4D's one-week confirmatory p-value is DK(4). Later Parts 4G–4K specify DK(5) procedures, sometimes with calendar gaps preserved. DK(4), compressed-time DK(5) and calendar-week-aware DK(5) must be explicitly labelled and not treated as interchangeable. Clean t−1 results stop at outcome week 24 February 2025 because of the post-March-2025 weekend-session timing issue.

The cross-summary consistency audit read seven component independent-QA reports (Parts 4D lag-window, 4F, 4G, 4H, 4I, 4J and 4K); all were PASS. Part 4L is a cross-summary audit, not a new independent re-estimation. Original source/model panels were not modified.

The thesis must continue to avoid causal language, investor-identity claims, unique-searcher claims, and out-of-sample forecast claims. Corrected SFIN query and expanded multi-query collection remain outstanding; Park5 excludes overnight jumps; returns are from a smaller dividend-qualified subset; and no rolling out-of-sample forecast exercise has been completed. The integrated thesis conclusion is: no statistically significant average one-week pooled ASVI–Park5 association is detected in the clean confirmatory sample; secondary evidence is horizon-, estimator-, regime- and firm-specific and is reported separately.


---

## Part 4M amendment — SFIN and archived multi-query measurement audit (16 November 2026)

Part 4M is a source-data audit only. It does not collect new Wordstat data, construct a composite, alter the 73-firm attention panel, or re-estimate any model. Detailed report: 04_design/Part_04M_Search_Measurement_Audit_2026-11-16_v1.md.

MOEX identifies SFIN as the common share of ПАО «ЭсЭфАй». The company's 2024 consolidated accounts state that it was ПАО «САФМАР Финансовые инвестиции» until 3 September 2021. The archive contains three series:
- «SFIN»: 417 positive weeks, 2 zeros, 410 valid ASVI observations; ticker-only channel, not a Russian-name substitute.
- «СФИ акции»: 389 zeros out of 419 weeks, 30 positive counts, 12 valid ASVI observations; reject as a usable primary query.
- «акции ЭсЭфАй»: zero in all 158 weeks before the name change; 255 positive weeks of 261 post-change weeks and 251 valid ASVI observations. First valid ASVI week 11 October 2021. Keep as a post-rebranding sensitivity only, not a full-window query.

No saved Wordstat export for the old name «САФМАР Финансовые инвестиции» was located in the searched Desktop/V6 archive. The recommended collection protocol records four old-name candidates, one new-name alternative and the existing ticker-only series separately in 02_data_audit/part04m_sfin_query_collection_protocol_v1.csv. No collection has been done.

The archived pairwise table contains 106 query-pair records. Among the 88 selected-query-to-alternative comparisons, 53 are near-duplicate candidates, 16 need semantic-alias review, 14 have low coverage/long zero runs, two are separate historical-name/brand reviews (FEES: «Россети» versus historical «ФСК ЕЭС»; FESH: «ДВМП» versus «ФЕСКО»), two YAKG entries incorrectly refer to the separate YKEN/Якутскэнерго issuer, and one RGSS-folder export has a Wordstat header for «акции КАМАЗа». The 16 semantic-alias review records are separate from the two historical-name/brand reviews. The semantic-alias queue includes SBER, GMKN, VTBR, NKNC, AVAN, AFKS, NVTK, RGSS, PLZL, VSMO, MSTT and PIKK. None is approved as a composite component. Wordstat statistics and pairwise correlation do not prove unique searchers or mutually exclusive query sets. Do not sum raw counts or add reversed word-order variants automatically.

The current 73-firm clean panel and Part 4D result remain unchanged; SFIN and MRKK remain excluded. Four protected primary files were re-hashed and were unchanged. The two archived SFIN-folder series matched their original source manifest hashes. No model was rerun.

Part 4M conclusion: retain the current one-query-per-firm primary measurement; pursue old-name SFIN collection only as a separately documented measurement update; do not create a multi-query index until semantic intent, historical issuer identity, and query reliability are checked. The Part 4L confirmatory result remains authoritative.


Part 4M integrity manifest: 01_input_manifest/part04m_measurement_audit_manifest_sha256_v1.csv (24 entries; per-file verification PASS, zero hash errors). The manifest file's own SHA-256 is recorded separately outside the files it covers.

---

## Part 4N amendment — SFIN legacy-name Wordstat access preflight (16 November 2026)

The legacy-name collection was not executed because this workflow has no authenticated interactive Wordstat session or authorised Search API access. A public page fetch returned an anonymous landing response; it does not establish the login state of the user's separate browser. No credential or cookie data were accessed.

Yandex's current interface guide requires login and allows weekly windows up to five years, so the V6 target span cannot be exported in one web-interface request. For each of five uncollected phrases (four former-name variants and one current-name alternative), download two separate weekly CSVs:
- W1: picker 27 Aug 2018–27 Aug 2023 (Monday–Sunday bounds), expected Monday labels 27 Aug 2018–21 Aug 2023 (261 weeks).
- W2: picker 28 Aug 2023–6 Sep 2026 (Monday–Sunday bounds), expected Monday labels 28 Aug 2023–31 Aug 2026 (158 weeks).

The combined schedule yields 419 adjacent Monday labels. Settings remain all regions, all devices and weekly Dynamics. Keep all ten exports raw and separate. The final Monday-labelled week of 31 Aug 2026 closes on Sunday 6 Sep 2026. Current-name and ticker exports already archived are not recollected. The current Search API documentation requires role search-api.webSearch.user; its notice about dates after 7 Oct 2026 does not affect the target end date of 6 Sep 2026. No Wordstat values or models were created in this stage.

Checkpoint: 04_design/Part_04N_SFIN_Legacy_Name_Collection_Access_Preflight_2026-11-16_v1.md. Export schedule: 02_data_audit/part04n_sfin_collection_windows_v1.csv. No change to the 73-firm primary panel.
