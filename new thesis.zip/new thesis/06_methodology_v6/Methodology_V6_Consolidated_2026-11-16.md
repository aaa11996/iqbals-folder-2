# Web Search Queries and Market Movements
## Consolidated V6 Research Methodology

**Research setting:** Russian MOEX-listed equities  
**Primary search source:** Yandex Wordstat  
**Primary outcome:** Weekly five-session-equivalent Parkinson within-session variance  
**Version date:** 16 November 2026  
**Document status:** Consolidated detailed methodology and current analytical specification  
**Project version:** V6; integrates the cleaned Part 4D primary design and completed Parts 4E–4N checkpoints where relevant.

---

## Executive summary

This thesis examines whether abnormal Russian-language searches for individual listed companies are associated with subsequent within-session stock-price variance on the Moscow Exchange (MOEX). The main search series comes from Yandex Wordstat. The main price outcome is a weekly measure constructed from daily Parkinson high–low variance.

The current analytical population is 73 MOEX firms. The underlying search panel covers 419 Monday-labelled weeks from 27 August 2018 to 31 August 2026. The clean one-week primary model uses 22,687 firm-week observations across 73 firms and 313 observed weeks, ending 24 February 2025. The shorter outcome window is deliberate: from March 2025, MOEX weekend sessions are treated as additional sessions of the following Monday, which can make the Monday-labelled price observation overlap in real time with the preceding Monday–Sunday Wordstat week.

The primary model is a two-way fixed-effects panel regression of log Parkinson variance on prior-week firm-specific abnormal search volume and lagged own volatility. The main coefficient is positive but statistically inconclusive: β = +0.03107, Driscoll–Kraay Bartlett bandwidth 4 standard error = 0.02290, p = 0.1750, 95% confidence interval [−0.01383, +0.07596]. A doubling of search activity relative to the preceding eight-week median corresponds to an estimated 2.18% increase in Park5 variance, with an interval that includes small negative and positive effects.

The thesis reports secondary results separately. A two-week lag is statistically detectable in its own model; the ASVI slope changes around the 2022 regime break; alternative intraday estimators and selected firm-specific slopes produce some discoveries. Returns, overnight-inclusive volatility, peer attention and sanctions interactions do not produce robust pooled findings in their main specifications. None of these results establishes causality or improved out-of-sample forecasting.

This document replaces inconsistent earlier summaries. In particular, use the cleaned 73-firm Part 4D result as the current primary result, not the historical 74-firm estimates in Parts 4B–4C or the older 75-firm planning language in early V6 draft paragraphs.

## 1. Research objective, question and estimand

### 1.1 Objective

The objective is to test whether an increase in public search activity concerning a listed company contains information about that company's subsequent within-session price variance. The setting is the Russian equity market and the search provider is Yandex Wordstat.

The empirical question is:

> Does abnormal Russian-language search activity for a MOEX-listed issuer during a completed Monday–Sunday week have an association with that issuer's Parkinson within-session variance in the following MOEX trading week?

A secondary question is whether the conditional relationship differs across the broad market regime change surrounding February 2022. Additional analyses examine alternative horizons, alternative volatility estimators, returns, firm heterogeneity, temporal feedback, sector peers and designation-history interactions.

### 1.2 Unit of observation

The principal unit is the issuer–week. Each firm-week is keyed by the Monday starting the Wordstat Monday–Sunday week. Daily MOEX data are aggregated to the same Monday key.

### 1.3 Primary estimand

The primary estimand is the within-firm association between prior-week abnormal search activity and next-week log Park5 variance, conditional on the firm's lagged log Park5 variance and common weekly shocks absorbed by week fixed effects.

The coefficient is not a causal effect of investor attention. Search records do not identify a unique person, investor status, investment intention, or whether a search led to a trade. The term *predictive association* describes the time ordering in the panel equation; it does not mean that search data have demonstrated out-of-sample forecasting gains.

### 1.4 Research hypotheses and status

The following statements describe the theoretical questions. They are not claims that the relevant hypotheses were formally preregistered.

- **H1 (primary):** Prior-week abnormal issuer-name search activity is associated with next-week issuer-level within-session variance. The directional sign is not forced because attention may increase information arrival and trading, while information acquisition may also reduce uncertainty.
- **H2 (secondary):** The association differs across the broad 2022 market-regime break.
- **H3 (secondary):** Search activity may contain predictive information at horizons longer than one week.
- **H4 (exploratory):** The relationship may differ across issuers.
- **H5 (exploratory):** Search activity and volatility may exhibit predictive feedback in both directions.
- **H6 (exploratory):** Peer attention, peer volatility or designation-history exposure may moderate the own-firm relationship.

**Preregistration disclosure:** Earlier versions of the research plan and empirical outputs existed before V6 was consolidated. The current V6 design should therefore not be described as a preregistered study. It is a version-controlled, evidence-audited research protocol with a designated primary specification and explicitly separated secondary analyses.

## 2. Sample, period and issuer identity

### 2.1 Original universe and cleaned estimation universe

The initial audited universe contained 75 securities. Following the search-query audit, the current Russian-name attention panel retains 73 firms. MRKK and SFIN are excluded from the present name-query primary panel because their selected Russian-language queries do not provide sufficiently continuous, reliable coverage over the full observation window.

ROLO remains in the 73-firm Park5 primary sample. An exclusion sensitivity is reported, but the earlier provisional exclusion from another weekly-range design does not automatically apply to the daily within-session Park5 estimator.

The 57-firm return sample is a distinct, selected subset that passes the annual dividend-history coverage gate. It must not be presented as if it were the same population as the 73-firm Park5 sample.

### 2.2 Observation window

The underlying weekly grid contains 419 Monday-labelled observations from **27 August 2018 through 31 August 2026**. The one-week primary price model uses a clean outcome window ending **24 February 2025** because of the MOEX weekend-session timing issue described in Section 6.

### 2.3 Issuer identity and security continuity

The original security-master audit mapped the initial 75 tickers to 75 unique ISINs. Issuer identity must be distinguished from ticker labels and from search phrase identity.

A documented transition exists from old YNDX to new YDEX in 2024. No return is calculated across that security-identity transition. The Latin ticker-only attention series is also treated as a query-definition break around the transition unless a documented bridge and a new ASVI warm-up are constructed.

An issuer-name search series can continue to represent public interest in the company through a ticker change, but that does not justify calculating a security return across two different traded instruments without an explicit identity bridge.

The Part 4M issuer audit also corrected a separate identity issue: YAKG represents YaTEK (ЯТЭК); Yakutskenergo is YKEN. A Yakutskenergo search phrase must not be assigned to YAKG.

### 2.4 Sample definitions that must remain distinct

| Analysis | Population | Current sample size | Important qualification |
|---|---:|---:|---|
| Primary Russian-name ASVI / Park5 | Clean attention panel | 73 firms; 22,687 observations | Clean t−1 outcome window through 24 Feb 2025 |
| Two-week Park5 lag | Same 73-firm universe | 22,622 observations | Separate horizon specification; not a formal t−2 versus t−1 difference test |
| Returns | Dividend-history-qualified subset | 57 firms; 17,747 observations | Gross primary-cash-adjusted candidate, not a fully reconstructed reinvestment TRI |
| Overnight-inclusive daily return-squares volatility | Dividend-history-qualified subset | 57 firms; 17,005 observations | Separate volatility proxy, not tick-level realized variance |
| Common peer-attention / peer-volatility model | Peer-eligible firms | 70 firms; 21,728 observations | Three saved sector labels are singletons and cannot supply two same-sector peers |
| Sanctions peer-share models | Peer-eligible firms | 70 firms; 21,748 observations | Peer predictor does not require peer Park5 availability; difference from 4J is intentional |

## 3. Data sources and audit trail

### 3.1 Yandex Wordstat

The attention source is weekly Yandex Wordstat Dynamics data. For each firm the primary series is one selected Russian-language company or brand name combined with the Russian word «акции» (shares/stocks). The exact query is the wording recorded in the original Wordstat export header and query registry.

The Latin ticker-only channel is retained separately as a secondary comparison. It is not added to the Russian-name counts and is not used as a firm-by-firm substitute when the Russian-name series is weak.

Wordstat reports searches containing the submitted phrase, including possible grammatical forms. The tool does not provide unique-user identities or a historical table of mutually exclusive search-query sets. The Dynamics interface uses Monday–Sunday weeks; its documented history begins in January 2018 and the weekly/monthly interface range is limited to five years per request. It supports regional and device filters and CSV export. The collection settings for the current panel are retained in the query registry and source files.

### 3.2 MOEX trading data

The price source comprises daily issuer-level open, high, low, close, share volume and ruble turnover/value, plus market-session and IMOEX information used for weekly eligibility. Official MOEX security metadata and trading-history checks support issuer identity and calendar alignment.

The Part 3 audit covered 150,449 active daily OHLC observations. The combined weekly firm files were reconciled against fresh daily aggregation for weekly OHLC, session counts, volume and value. The linked IMOEX fields were also reconciled.

### 3.3 Dividends and corporate actions

The v5.3 dividend workbook supports the separate return and historical adjusted-range analyses. The workbook distinguishes confirmed payment, no-payment and unknown-coverage histories. Unknown must never be treated as zero.

The current Park5 primary outcome is calculated from each day's own-session high and low. It does not combine a pre-dividend close with a post-dividend close in a weekly maximum–minimum range. Park5 therefore avoids the mechanical overnight price-level jump that can affect a weekly high–low range spanning an ex-dividend date. It does not measure overnight risk, and dividends may still affect within-session trading behaviour.

The dividend-adjusted return strand remains subject to the 57-firm history gate and corporate-action checks. It is secondary.

### 3.4 Frozen source and reproducibility rules

Original source files are read-only. New query variants are separate source inputs and must retain the exact phrase, issuer rationale, export header, settings, date range and SHA-256 hash. No raw source file should be overwritten.

Each analytical stage keeps versioned scripts, input manifests, result tables, independent QA reports and a dated checkpoint. A successful QA re-estimation verifies implementation consistency; it does not establish that the model is correctly specified or that its identifying assumptions are true.

## 4. Measuring online search activity

### 4.1 Primary query channel

The selected primary query for each retained firm is a Russian-language issuer/company/brand name plus «акции». The query is more finance-specific than a bare company name or ticker, but it still cannot guarantee that every search was made by an investor or with the intention to trade.

The source audit reconstructed the exact wording of 150 channel definitions. The cleaned dataset retains one selected Russian-language query and one separate ticker-only series for each included firm. The median raw weekly count was 723 for the Russian-name/brand channel and 98 for the ticker-only channel in the audited working universe. These are descriptive channel-level statistics, not proof that the Russian-name query is a valid investor-only measure.

### 4.2 Canonical abnormal search volume

For issuer *i* and week *t*, canonical ASVI is:

$$
ASVI_{i,t}=\ln(SVI_{i,t})-\ln\left[\operatorname{median}(SVI_{i,t-1},\ldots,SVI_{i,t-8})\right].
$$

The first term is the logarithm of the current week's raw count. The second term is the logarithm of the median of the eight immediately preceding weekly raw counts. This is the **logarithm of the median raw count**, not the median of eight log-transformed observations under an alternative even-sample convention.

The transformation expresses current query volume relative to the query's own recent baseline. It is not a standardized cross-company attention score. Without additional standardization, absolute ASVI magnitudes should not be interpreted as directly comparable levels of attention across issuers.

### 4.3 Zero counts and missing values

A true zero count is retained in the raw SVI data. Canonical ASVI is undefined if the current-week count is zero or if the median of the preceding eight weeks is zero. The primary ASVI does not replace these values with zero, interpolate them, or silently use log(1 + SVI).

The cleaned Russian-name panel has 30,587 firm-week cells (73 × 419) and 29,995 valid canonical ASVI values. The 592 undefined values consist of 584 initial eight-week warm-up cells and eight current-week zero-count cells. No primary imputation is applied.

The ticker-only panel is kept separate. It has 30,587 cells, 1,034 zero-count weeks and 28,936 valid ASVI values. It is a secondary attention channel, not a replacement for the primary name query.

### 4.4 Search-query validity and coverage

Each candidate query is reviewed for issuer identity, financial intent, search volume, zero-count frequency, long zero runs, and whether its wording is ambiguous or refers to another entity. A query with a high count is not automatically superior; semantic validity is essential.

The primary sample excludes MRKK and SFIN. The old SFIN phrase «СФИ акции» has 389 zero weeks out of 419 and only 12 valid ASVI observations. The current-name phrase «акции ЭсЭфАй» has zero counts in all 158 pre-renaming weeks, so it can only support a post-rebranding sensitivity. The SFIN ticker series is dense but belongs to the separate ticker-only channel.

Part 4N prepared a ten-export schedule for five separate SFIN candidate phrases, each collected over two adjacent date windows. No new export was collected during the access preflight; the status is **NOT COLLECTED / ACCESS REQUIRED**. SFIN remains excluded until these source exports are genuinely obtained and validated.

### 4.5 Multi-query measurement rules

The archive review compared selected query series with alternatives. Correlation measures co-movement; it does not show that user populations are disjoint or that two queries have identical underlying searches. High correlation can arise because two different phrases respond to the same news. Low correlation can arise from sparse counts, zero inflation, sampling noise or different search intent.

The following rules apply to any future query-basket experiment:

1. Keep each candidate phrase as an independent raw series with its own query header and hash.
2. Calculate coverage, zero incidence, longest zero run, ASVI validity and overlap weeks separately for each phrase.
3. Compare log(1 + raw count) and ASVI using Pearson and Spearman correlations on clearly stated overlapping samples. Show sample sizes and uncertainty where feasible.
4. Review Wordstat Top Queries output to understand recent query composition, but do not treat it as a historical query-intersection table.
5. Never sum phrase counts unless the underlying query events can be shown to be mutually exclusive.
6. If multiple phrases appear to measure the same construct but are not disjoint, a normalized equal-weight average of their valid query-specific ASVI values may be tested as a separate index. Record the number of valid components for every firm-week. This is an attention index, not a total search count.
7. If semantic intent differs or overlap is inadequate, keep the phrases separate.
8. Preserve the original one-query primary result as a benchmark. Do not replace it with a composite because the composite produces a stronger coefficient.

## 5. Measuring within-session volatility

### 5.1 Daily Parkinson estimator

For issuer *i* on trading day *d*, daily Parkinson variance is:

$$
Park_{i,d}=\frac{[\ln(H_{i,d}/L_{i,d})]^2}{4\ln 2},
$$

where *H* and *L* are that day's high and low.

For firm *i* and Monday-labelled week *t*, the five-session-equivalent weekly measure is:

$$
Park5_{i,t}=\frac{5}{n_{i,t}}\sum_{d\in t}Park_{i,d},
$$

where *n* is the number of active stock-trading sessions in the week. The model outcome is:

$$
Y_{i,t}=\ln(Park5_{i,t}).
$$

This scaling expresses the observed weekly sum on a five-session-equivalent basis. It does not create observations for non-trading days.

### 5.2 Eligibility rule

A firm-week qualifies for primary Park5 when:

- the firm has at least four active stock-trading sessions; and
- those sessions are at least 80% of the actual IMOEX market sessions in that week.

This allows normal four-session holiday-shortened market weeks while excluding firm-weeks with materially incomplete trading. A strict five-session rule is retained as a sensitivity. Weeks with no trading or with insufficient firm-level sessions are not converted to zero volatility.

### 5.3 Meaning and limitation of Park5

Park5 uses only high and low prices within each trading session. It measures **within-session intraday variance**. It does not contain overnight, weekend or between-session jumps and must not be labelled total weekly realized volatility.

The same-session high/low ratio also avoids joining price levels across an ex-dividend close and the next session's ex-date price. However, Park5 does not remove all dividend-related effects on trading behaviour, nor does it capture the total risk borne by an investor holding the stock overnight.

### 5.4 Alternative OHLC estimators

Garman–Klass and Rogers–Satchell are secondary OHLC-based estimators. Their independent reconstruction matched the saved Part 3 values to numerical precision. They are robustness outcomes and are not selected based on which produces a smaller p-value.

Yang–Zhang includes overnight price movement. It is not the primary outcome and would require careful separate checks for corporate actions, dividends, long gaps and instrument identity changes.

### 5.5 ROLO treatment

ROLO remains in the 73-firm Park5 primary sample. A ROLO-excluded specification is retained as sensitivity. The decision is based on the daily within-session estimator and the completed tick/session audit; the earlier weekly adjusted-range exclusion should not be carried over automatically.

## 6. Weekly timing and the 2025 weekend-trading issue

Wordstat weekly Dynamics covers Monday through Sunday and labels the week by Monday. All joins use that Monday date.

The baseline model matches search ASVI from the completed week *t−1* to Park5 in week *t*. The lag is generated on the complete Monday-week grid before model rows are filtered. The same rule applies to other lagged variables. Missing market weeks are not removed first and then treated as if adjacent remaining observations were consecutive weeks.

On 28 February 2025, the Bank of Russia stated that Saturday and Sunday stock-market sessions would be treated as additional sessions of the following Monday, rather than standalone trading days. MOEX launched the additional weekend session from 1 March 2025. A Monday-labelled OHLC observation after the rollout can therefore include weekend trading that occurred during the previous Monday–Sunday Wordstat week. That creates a real-time overlap between the previous week's search measure and the outcome week.

To preserve strict one-week ordering, the primary t−1 model ends with outcome week **24 February 2025**. Later observations are not silently included in the primary one-week model. They may be used in separately labelled timing sensitivities. The clean t−2 model is a distinct two-week horizon and is reported separately; it is not used to replace the one-week primary based on statistical significance.

## 7. Primary econometric specification

### 7.1 Baseline model

The primary panel equation is:

$$
\ln(Park5_{i,t})=\alpha_i+\lambda_t+\beta ASVI^{name}_{i,t-1}+\rho\ln(Park5_{i,t-1})+\varepsilon_{i,t}.
$$

Where:

- \(\alpha_i\) is the firm fixed effect;
- \(\lambda_t\) is the week fixed effect;
- \(ASVI^{name}_{i,t-1}\) is prior-week Russian-name ASVI;
- \(\ln(Park5_{i,t-1})\) controls for own-volatility persistence;
- \(\beta\) is the single confirmatory coefficient.

Firm effects absorb time-invariant differences across issuers. Week effects absorb common weekly shocks, including market-wide movements and common information shocks. As a consequence, the main coefficient is identified from within-firm changes in ASVI relative to the weekly common component. The model does not estimate the impact of a common market-wide search shock shared by all firms in a given week.

### 7.2 Turnover-augmented model

A nested specification adds lagged ruble turnover:

$$
\ln(Park5_{i,t})=\alpha_i+\lambda_t+\beta_V ASVI^{name}_{i,t-1}+\rho_V\ln(Park5_{i,t-1})+\theta\ln(VALUE_{i,t-1})+\varepsilon_{i,t}.
$$

VALUE is ruble turnover, not the number of shares traded. This model asks whether ASVI contributes information beyond prior trading activity. Turnover may also lie on the mechanism through which attention affects volatility, so this is a nested explanatory sensitivity, not a replacement for the baseline. A control is not added or removed because it improves statistical significance.

### 7.3 Primary inference

The primary covariance estimator is Driscoll–Kraay with a Bartlett kernel and bandwidth 4 weekly periods, denoted DK(4). Sensitivity inference uses DK(8) and two-way firm/week clustering.

Each primary table reports the coefficient, standard error, confidence interval, p-value, observation count, firm count, observed week count and within R-squared. The coefficient's economic magnitude is interpreted for an ASVI increase of \(\ln(2)\), corresponding to doubling current query volume relative to the preceding eight-week median.

The one Russian-name ASVI(t−1) coefficient in the Park5 baseline is the sole confirmatory model coefficient. Other outcomes, lags, estimators, interactions, query definitions and firm-level tests are secondary or exploratory.

### 7.4 Multiple testing

Secondary hypothesis families are declared by analysis stage and corrected using Holm and/or Benjamini–Hochberg as specified in the corresponding checkpoint. Raw p-values from large families of firm-specific or alternative-specification tests are not enough to identify a reliable effect.

Do not combine results from different analysis families into one ad hoc family after observing which tests are significant. Do not compare DK(4), compressed-time DK(5) and calendar-week-aware DK(5) p-values as if they were generated by the same covariance construction.

## 8. 2022 regime-slope analysis

The secondary 2022 analysis asks whether the conditional ASVI slope changed across a broad market-regime break. The primary break indicator uses the outcome-week label beginning 21 February 2022; this week contains 24 February and is treated as a transition week in the main definition. Sensitivities exclude the transition week or the market suspension/reopening period and use alternative post-start dates.

The interaction model is:

$$
\ln(Park5_{i,t})=\alpha_i+\lambda_t+\beta ASVI_{i,t-1}+\gamma(ASVI_{i,t-1}\times Post_t)+\rho\ln(Park5_{i,t-1})+\varepsilon_{i,t}.
$$

The pre-break slope is \(\beta\); the implied post-break slope is \(\beta+\gamma\). A common post dummy is absorbed by week fixed effects. The interaction identifies a difference in conditional slope, not the causal impact of the invasion, sanctions, market closure, reopening or any single contemporaneous event.

The cleaned 73-firm result is \(\gamma=-0.12738\), DK(4) p = 0.00401, and Holm-adjusted p approximately 0.01198 across the three declared break/suspension-window definitions. The implied post-break slope is −0.04347 with p = 0.20485. Thus, evidence supports a slope change; it does not support the claim that the post-break slope itself is significantly negative.

The week of 21 February 2022 is a transition week. The Bank of Russia reported a halt in stock and forward trading from 28 February, gradual reopening from 21 March and a return to the regular trading regime on 11 April. The model's eligibility rule leaves a calendar gap around the suspension. These conditions make the break analysis important but observational and regime-descriptive.

## 9. Completed secondary analyses and current results

This section records the current completed analysis status so that the methodology is aligned with the results archive. These analyses do not replace the primary model.

### 9.1 Lag-by-window diagnostic

Part 4D compared one- and two-week lags and clean/full windows. The clean t−1 Park5 estimate remains positive but inconclusive. The clean t−2 estimate is positive and statistically detectable: β = +0.11207, calendar-week-aware DK(5) p = 9.50 × 10⁻⁷, N = 22,622, 73 firms, 312 observed weeks. The t−2 model is a separate horizon specification; it is not a formal test that β(t−2) differs from β(t−1). The primary t−1 model remains unchanged.

### 9.2 Alternative intraday volatility estimators

The predeclared secondary Part 4D family includes alternative specifications and estimator outcomes. Garman–Klass has β = +0.07285, DK(4) p = 0.00162 and Holm p = 0.00975. Rogers–Satchell has β = +0.12937, DK(4) p = 1.30 × 10⁻⁷ and Holm p = 1.04 × 10⁻⁶. These are estimator-specific secondary findings. Park5 remains the single confirmatory outcome.

### 9.3 Returns

The firm-level weekly return outcome is:

$$
R^{cash}_{i,t}=\ln\left(\frac{CLOSE_{i,t}+D^{primary}_{i,t}}{CLOSE_{i,t-1}}\right).
$$

This is a gross primary-cash-adjusted weekly log-return candidate. It is not a fully reconstructed dividend-reinvestment total-return index. The sample has 57 firms and 17,747 observations. Its pooled ASVI(t−1) coefficient is −0.000323, calendar-week-aware DK(5) p = 0.7602. No robust pooled one-week return association is detected.

### 9.4 Overnight-inclusive volatility proxy

A separate secondary outcome sums squared valid daily close-to-close gross log returns within each week. It includes overnight/weekend movements between traded closes, but it is not a high-frequency tick-level realized-variance estimate. It is restricted to the 57 dividend-history-qualified firms and 17,005 clean observations. The ASVI coefficient is +0.01685, DK(5) p = 0.6275. This result is inconclusive and does not replace the 73-firm Park5 primary result.

### 9.5 Heterogeneous firm-specific volatility slopes

Part 4G estimates firm-specific ASVI and lagged-volatility slopes jointly, retaining firm and week fixed effects. In the 73-firm clean Park5 sample, 10 firms have raw p-values below 0.05; two survive Holm correction (PHOR and SIBN), and five survive Benjamini–Hochberg. Coefficients are mixed in sign: 40 positive and 33 negative. These are exploratory firm-specific conditional relationships, not a replacement for the pooled confirmatory result.

Two-way firm/week clustered inference is not interpreted for ticker-specific interaction slopes that are active in only one entity cluster. The firm-cluster component is not identified meaningfully for that coefficient. The reported firm-level inference uses DK(5) as primary, with DK(4) and DK(8) sensitivities.

### 9.6 Firm-specific return slopes

Part 4H estimates 57 firm-specific return slopes in the selected dividend-history sample. Four raw p-values are below 0.05, but none survives Holm or Benjamini–Hochberg. The coefficients are mixed in sign. These results do not support robust firm-level return effects.

### 9.7 Granger-style lead–lag tests

Part 4I estimates pooled cross-lag blocks at orders 1, 2 and 4 in both directions. Lags are generated on the complete 419-week calendar before rows are filtered. The pooled Park5 levels tests find no ASVI → Park5 incremental predictive content at lag order 1 (DK(5) p = 0.1780; Holm p = 0.5448), but the lag-2 and lag-4 cross-lag blocks survive Holm correction. Reverse Park5 → ASVI blocks survive Holm at all three lag orders.

First-difference \(\Delta ASVI\rightarrow\Delta\ln(Park5)\) sensitivity tests also survive their separate Holm family at lag orders 1, 2 and 4. For cash-adjusted returns, ASVI does not predict returns at any tested lag order. These are temporal predictive-content tests, not structural causality and not out-of-sample forecasting evidence. The bidirectional findings caution against a one-way story in which search attention only precedes volatility.

### 9.8 Sector peer attention and peer volatility

Part 4J constructs equal-weighted, leave-one-out peer averages within the saved sector labels, shifted by one complete week. It requires at least two other firms with valid values. Three sectors are singletons and do not contribute. The common sample contains 70 firms and 21,728 observations.

The combined model yields peer-ASVI β = +0.00479 (DK(5) p = 0.9064) and peer-log-Park5 β = +0.02054 (DK(5) p = 0.2787); their joint test p = 0.4074. These findings are inconclusive. Equal-weight peer averages are sample-based, not historical market-cap-weighted measures, and they do not prove causal spillovers.

### 9.9 Sanctions and sector designation interactions

Part 4K uses direct L1 designation-history indicators from US OFAC, EU and UK lists and a leave-one-out sector peer concentration measure. The source workbook contains 85 direct-designation rows (72 L1 and 13 L2); the current model's primary own-firm treatment is cumulative ever-direct L1 history, not current in-force status. No ownership-implied exposure is coded.

The combined model's own L1-history × ASVI coefficient is −0.01092 (DK(5) p = 0.8158). The peer L1-share × ASVI coefficient is −0.08861 (DK(5) p = 0.1219); the joint interaction test p = 0.2498. No tested interaction provides robust evidence of moderation. The peer share is the designation concentration among the study's sample firms, not an official sector-level exposure measure. The external-source workbook QA date is 31 October 2026; the V6 stage independently reconstructed workbook matrices but did not freshly re-download every official locator.

## 10. Robustness, diagnostic and reporting rules

The current completed robustness and secondary checks include:

1. DK(8) and two-way firm/week clustered inference for the primary coefficient.
2. Garman–Klass and Rogers–Satchell alternative outcomes.
3. Strict five-session and unscaled weekly variance alternatives.
4. ROLO-excluded primary-model sensitivity.
5. Lagged ruble turnover augmentation.
6. Separate Latin ticker-only ASVI proxy.
7. Clean and full-window timing sensitivities, with full-window t−1 explicitly not treated as the clean primary after weekend trading starts.
8. Alternative 2022 break/suspension-window definitions.
9. Separate returns and overnight-inclusive volatility samples.
10. Heterogeneous firm-level, lead–lag, peer and sanctions analyses with declared multiple-testing families.

A model's primary/secondary status is fixed by the research design and cannot be changed after observing statistical significance. All reported coefficients must be paired with the exact outcome, sample, timing, covariance estimator and correction family.

## 11. Limitations and interpretation boundaries

- **Search construct:** Wordstat counts query activity, not unique individuals. It cannot establish that a user is an investor, retail investor, institution or trader.
- **Query intent:** Company-name + «акции» narrows search intent but does not eliminate curiosity, job searches, general company research, news checking or other motives.
- **Provider and platform:** Google Trends evidence does not directly validate Yandex Wordstat. Provider differences and query processing must be acknowledged.
- **Coverage:** low-volume queries can have zero counts and undefined ASVI. SFIN and MRKK remain excluded from the current Russian-name primary analysis.
- **Outcome scope:** Park5 excludes overnight jumps and measures within-session high–low variance, not total investor risk or total realized variance.
- **Timing:** after March 2025 the additional weekend sessions are assigned to the following Monday. The clean one-week model ends in February 2025.
- **Selection:** the 57-firm return sample is a dividend-history-qualified subset and differs from the 73-firm volatility universe.
- **Confounding and feedback:** common news, firm-specific announcements, market events and reverse responses may influence both searches and prices. Lagged regressors and fixed effects do not eliminate all omitted-variable bias or reverse feedback.
- **2022 regime:** the interaction captures a broad conditional slope change amid multiple simultaneous changes; it does not isolate a single causal event.
- **Forecasting:** no rolling-origin or expanding-window out-of-sample forecast test has been completed. Do not claim that Wordstat improves forecasts.
- **Preregistration:** earlier versions/results existed. The study should not be described as formally preregistered.

All conclusions should be framed as associations, descriptive regime differences or in-sample predictive content, according to the model used. Avoid the terms “causes,” “investors searched,” “retail investors’ attention” or “forecasting improvement” unless additional evidence directly supports the specific claim.

## 12. Version reconciliation and current stop point

The authoritative primary analysis is the cleaned Part 4D 73-firm Park5 model. Earlier 74-firm Part 4B/4C values are historical and superseded. The current analysis retains ROLO; SFIN and MRKK are excluded from the Russian-name ASVI primary series. The separate 57-firm return sample is not interchangeable with the 73-firm primary sample.

Parts 4D through 4K provide the current empirical results; Part 4L reconciles the thesis-wide results; Part 4M audits the search measurement archive; Part 4N completes only an access preflight for SFIN legacy-name queries. Part 4N did not collect ten CSVs, create new ASVI values, change the 73-firm panel or run any new model. The next query-collection stage is blocked until the required raw CSV exports or an authorised API route are available.

This methodology document consolidates completed design decisions and the current result status. The proposed experiments in the companion literature-review document remain proposals and must not be represented as completed analyses.

## 13. References and source documentation

- Bank of Russia (28 February 2025). *Setting parameters of weekend trading*. https://www.cbr.ru/press/event/?id=23428
- Moscow Exchange (24 February 2025). *Moscow Exchange launches weekend trading on the stock market*. https://www.moex.com/n77931
- Yandex. *Wordstat interface and Dynamics*. https://yandex.ru/support2/wordstat/en/interface/new
- Yandex. *Structure of the Wordstat API: weekly, monthly and daily query dynamics*. https://yandex.ru/support2/wordstat/en/content/api-structure
- Da, Z., Engelberg, J., & Gao, P. (2011). In search of attention. *The Journal of Finance, 66*(5), 1461–1499. https://doi.org/10.1111/j.1540-6261.2011.01679.x
- Driscoll, J. C., & Kraay, A. C. (1998). Consistent covariance matrix estimation with spatially dependent panel data. *The Review of Economics and Statistics, 80*(4), 549–560. https://doi.org/10.1162/003465398557825
- Parkinson, M. (1980). The extreme value method for estimating the variance of the rate of return. *The Journal of Business, 53*(1), 61–65. https://doi.org/10.1086/296071
- Garman, M. B., & Klass, M. J. (1980). On the estimation of security price volatilities from historical data. *The Journal of Business, 53*(1).
- Shu, J., & Zhang, J. E. (2006). Testing range estimators of historical volatility. *Journal of Futures Markets, 26*(3), 297–313. https://doi.org/10.1002/fut.20197
- Newey, W. K., & West, K. D. (1987). A simple, positive semi-definite, heteroskedasticity and autocorrelation consistent covariance matrix. *Econometrica, 55*(3), 703–708. https://doi.org/10.2307/1913610

## Appendix A. Primary model reporting template

| Required item | Required disclosure |
|---|---|
| Dependent variable | ln(Park5), five-session-equivalent within-session Parkinson variance |
| Main regressor | Russian-name ASVI(t−1) |
| ASVI definition | ln(current weekly count) − ln(median of previous eight raw weekly counts) |
| Controls | ln(Park5(t−1)); lagged ln(VALUE) only in nested sensitivity |
| Fixed effects | Firm and week |
| Primary covariance | Driscoll–Kraay Bartlett DK(4) |
| Sensitivities | DK(8), two-way firm/week cluster, other declared measures |
| Primary sample | 73 firms; 22,687 firm-week observations; 313 observed weeks |
| Outcome timing | 29 Oct 2018–24 Feb 2025 |
| Coefficient | +0.03107 |
| Standard error / p-value | DK(4) SE 0.02290; p = 0.1750 |
| 95% confidence interval | [−0.01383, +0.07596] |
| Main interpretation | Positive estimate; statistically inconclusive average one-week association |

## Appendix B. Controlled terminology

| Use this term | Avoid this unsupported substitute |
|---|---|
| Search activity / search-query volume | Number of investors / unique investors |
| Public interest or information demand proxy | Direct measure of investor attention, without qualification |
| Within-session intraday variance | Total weekly realized volatility |
| Predictive association / temporal predictive content | Causal effect |
| 2022 regime-slope change | Causal effect of war or sanctions |
| Gross primary-cash-adjusted return candidate | Fully reconstructed total-return index |
| In-sample panel result | Forecasting improvement |
| 73-firm Park5 sample | 57-firm returns sample |

---

**End of consolidated V6 methodology.**